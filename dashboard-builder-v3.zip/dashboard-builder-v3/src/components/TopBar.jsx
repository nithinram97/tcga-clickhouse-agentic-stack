export default function TopBar({ spec, dirty, publishedVersion, onTitle, onUndo, onRedo, onSpec, onVersions, onPublish }) {
  return (
    <div className="topbar">
      <div className="brand">
        <div className="brand-mark" aria-hidden="true" />
        <div className="brand-name">Dashboards</div>
      </div>
      <input
        className="doc-title-input"
        value={spec.title}
        onChange={(e) => onTitle(e.target.value)}
        aria-label="Dashboard title"
      />
      <div className="topbar-right">
        <span className={dirty ? "chip" : "chip live"}>
          {dirty ? "Draft" : publishedVersion ? `Live · v${publishedVersion}` : "Draft"}
        </span>
        <button className="btn icon" onClick={onUndo} title="Undo (Ctrl+Z)">↶</button>
        <button className="btn icon" onClick={onRedo} title="Redo (Ctrl+Shift+Z)">↷</button>
        <button className="btn" onClick={onSpec}>Spec</button>
        <button className="btn" onClick={onVersions}>History</button>
        <button className="btn primary" onClick={onPublish}>Share</button>
      </div>
    </div>
  );
}
