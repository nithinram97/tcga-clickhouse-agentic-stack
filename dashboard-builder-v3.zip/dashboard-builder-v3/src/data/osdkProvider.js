import { GROUPINGS, AGGREGATIONS, OPERATORS } from "../config/propertyTypes.js";

/**
 * Real OSDK provider.
 *
 * Drop-in replacement for the mock — same five methods. Uncomment the imports,
 * pass your generated object types in, and change one line in main.jsx.
 *
 *   import { createClient } from "@osdk/client";
 *   import { createPublicOauthClient } from "@osdk/oauth";
 *   import * as Ontology from "@your-org/generated-sdk";
 *
 *   const auth = createPublicOauthClient(CLIENT_ID, FOUNDRY_URL, REDIRECT_URL);
 *   const client = createClient(FOUNDRY_URL, ONTOLOGY_RID, auth);
 *   const provider = createOsdkProvider(client, Ontology);
 *
 * Authenticate as the END USER, not a service account. If your backend proxies
 * queries with a service token, Foundry's row-level security stops applying and
 * every user sees every row.
 */
export function createOsdkProvider(client, ontologyModule, options = {}) {
  const { maxGroupCount = 100 } = options;

  // Every exported object type, discovered rather than hardcoded.
  const objectTypes = Object.fromEntries(
    Object.entries(ontologyModule).filter(([, v]) => v?.type === "object")
  );
  const defOf = (apiName) => {
    const d = objectTypes[apiName];
    if (!d) throw new Error(`Object type not in the generated SDK: ${apiName}`);
    return d;
  };

  const metaCache = new Map();

  return {
    id: "osdk",

    async listObjectTypes() {
      const out = [];
      for (const [apiName, def] of Object.entries(objectTypes)) {
        // client.fetchMetadata is what makes this ontology-agnostic: display
        // names and descriptions come from the ontology at runtime, so ontology
        // changes do not require a code change.
        const meta = await client.fetchMetadata(def);
        out.push({
          apiName,
          displayName: meta.displayName ?? apiName,
          description: meta.description
        });
      }
      return out;
    },

    async describeObjectType(apiName) {
      if (metaCache.has(apiName)) return metaCache.get(apiName);
      const meta = await client.fetchMetadata(defOf(apiName));

      const described = {
        apiName,
        displayName: meta.displayName ?? apiName,
        description: meta.description,
        primaryKey: meta.primaryKeyApiName,
        properties: Object.entries(meta.properties ?? {}).map(([pApi, p]) => ({
          apiName: pApi,
          displayName: p.displayName ?? pApi,
          description: p.description,
          // Normalised in config/propertyTypes.js — everything downstream reads
          // the kind, never the raw Foundry type name.
          type: p.type?.type ?? p.type
        })),
        links: Object.entries(meta.links ?? {}).map(([lApi, l]) => ({
          apiName: lApi,
          displayName: l.displayName ?? lApi,
          targetType: l.targetType,
          multiplicity: l.multiplicity
        }))
      };
      metaCache.set(apiName, described);
      return described;
    },

    /**
     * Distinct values for filter pickers, via a grouped count. Users pick from
     * what is actually in the data instead of typing a value and hoping.
     */
    async distinctValues(objectType, property, limit = 12) {
      const res = await client(defOf(objectType)).aggregate({
        $select: { $count: "desc" },
        $groupBy: { [property]: "exact" }
      });
      return res
        .slice(0, limit)
        .map((row) => ({ value: row.$group[property], count: row.$count }));
    },

    async numericRange(objectType, property) {
      const res = await client(defOf(objectType)).aggregate({
        $select: {
          [`${property}:min`]: "unordered",
          [`${property}:max`]: "unordered"
        }
      });
      return { min: res[`${property}`]?.min ?? 0, max: res[`${property}`]?.max ?? 0 };
    },

    /**
     * One aggregate call per widget. Multiple measures become multiple $select
     * keys; a split becomes a second $groupBy key.
     */
    async aggregate(query) {
      const { objectType, where, groupBy, split, measures, limit = 12 } = query;

      const $select = {};
      const order = groupBy ? "unordered" : "unordered";
      measures.forEach((m) => {
        const agg = AGGREGATIONS[m.fn];
        $select[agg.osdk ? `${m.property}:${agg.osdk}` : "$count"] = order;
      });

      const args = { $select };
      if (groupBy) {
        args.$groupBy = {
          [groupBy.property]: GROUPINGS[groupBy.strategy].build(groupBy.options)
        };
        if (split) {
          args.$groupBy[split.property] = GROUPINGS[split.strategy].build(split.options);
        }
      }

      let objectSet = client(defOf(objectType));
      if (where && Object.keys(where).length) objectSet = objectSet.where(where);

      const rows = await objectSet.aggregate(args);
      return shapeRows(rows, query, limit, maxGroupCount);
    }
  };
}

/**
 * OSDK returns a flat list of groups. The renderer wants
 * `{ keys, series }` — the same shape the mock returns.
 */
function shapeRows(rows, query, limit) {
  const { groupBy, split, measures } = query;
  if (!groupBy) {
    const r = Array.isArray(rows) ? rows[0] : rows;
    return {
      keys: ["All"],
      series: measures.map((m) => ({
        name: m.label,
        measureId: m.id,
        splitKey: null,
        values: [readMetric(r, m)]
      })),
      truncated: false
    };
  }

  const list = Array.isArray(rows) ? rows : [rows];
  const keys = [];
  for (const r of list) {
    const k = String(r.$group?.[groupBy.property] ?? "");
    if (!keys.includes(k)) keys.push(k);
  }
  const shown = keys.slice(0, limit);

  const series = [];
  const push = (name, measure, splitKey) => {
    const values = shown.map((k) => {
      const r = list.find(
        (row) =>
          String(row.$group?.[groupBy.property]) === k &&
          (splitKey == null || String(row.$group?.[split.property]) === splitKey)
      );
      return r ? readMetric(r, measure) : 0;
    });
    series.push({ name, values, measureId: measure.id, splitKey });
  };

  if (split) {
    const splitKeys = [];
    for (const r of list) {
      const s = String(r.$group?.[split.property] ?? "");
      if (!splitKeys.includes(s)) splitKeys.push(s);
    }
    splitKeys.slice(0, split.limit ?? 5).forEach((s) => push(s, measures[0], s));
  } else {
    measures.forEach((m) => push(m.label, m, null));
  }

  return { keys: shown, series, truncated: keys.length > shown.length };
}

function readMetric(row, measure) {
  if (!row) return 0;
  const agg = AGGREGATIONS[measure.fn];
  if (!agg.osdk) return row.$count ?? 0;
  // Results come back as row[propertyName][metric], per the OSDK docs.
  return row[measure.property]?.[agg.osdk] ?? row[`${measure.property}:${agg.osdk}`] ?? 0;
}

/** Composes the filter list into a single OSDK `where` clause. */
export function buildWhere(filters = []) {
  const clauses = filters
    .filter((f) => f.property && f.operator)
    .map((f) => OPERATORS[f.operator].build(f.property, f.value))
    .filter(Boolean);
  if (!clauses.length) return undefined;
  return clauses.length === 1 ? clauses[0] : { $and: clauses };
}
