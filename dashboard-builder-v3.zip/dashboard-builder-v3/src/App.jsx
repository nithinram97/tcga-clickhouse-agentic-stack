import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useOntology } from "./store/useOntology.js";
import { useDashboard } from "./store/useDashboard.js";
import { newWidget } from "./lib/spec.js";
import TopBar from "./components/TopBar.jsx";
import DataRail from "./components/DataRail.jsx";
import WidgetTile from "./components/WidgetTile.jsx";
import Inspector from "./components/Inspector.jsx";
import StartScreen from "./components/StartScreen.jsx";
import FilterEditor from "./components/FilterEditor.jsx";
import Drawer from "./components/Drawer.jsx";

export default function App() {
  const { objectTypes, metaFor, loading } = useOntology();
  const d = useDashboard(metaFor);
  const [drawer, setDrawer] = useState(null);
  const [toast, setToast] = useState(null);
  const [crossFilter, setCrossFilter] = useState(null);
  const dragId = useRef(null);

  const notify = useCallback((message, undo) => {
    setToast({ message, undo });
    setTimeout(() => setToast(null), 4000);
  }, []);

  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "z") {
        e.preventDefault();
        (e.shiftKey ? d.redo() : d.undo());
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [d]);

  const primaryType = d.spec.objectTypes[0];
  const dashboardFilters = useMemo(
    () => d.spec.filters ?? [],
    [d.spec.filters]
  );

  if (loading) {
    return <div className="boot">Reading your ontology…</div>;
  }

  if (!d.spec.widgets.length) {
    return (
      <>
        <TopBar
          spec={d.spec} dirty={d.dirty} publishedVersion={d.publishedVersion}
          onTitle={d.setTitle} onUndo={d.undo} onRedo={d.redo}
          onSpec={() => setDrawer("spec")} onVersions={() => setDrawer("versions")}
          onPublish={() => notify("Nothing to share yet")}
        />
        <StartScreen
          objectTypes={objectTypes}
          metaFor={metaFor}
          onAdd={(w) => d.addWidget(w)}
          onAddMany={(ws) => { d.addWidgets(ws); notify(`Added ${ws.length} charts`); }}
        />
        <SpecDrawer d={d} drawer={drawer} setDrawer={setDrawer} notify={notify} />
      </>
    );
  }

  return (
    <>
      <TopBar
        spec={d.spec} dirty={d.dirty} publishedVersion={d.publishedVersion}
        onTitle={d.setTitle} onUndo={d.undo} onRedo={d.redo}
        onSpec={() => setDrawer("spec")} onVersions={() => setDrawer("versions")}
        onPublish={() => { const v = d.publish(); notify(`Shared version ${v.version}`); }}
      />

      <div className="shell">
        <DataRail
          spec={d.spec}
          objectTypes={objectTypes}
          metaFor={metaFor}
          onAdd={(t) => { d.addObjectType(t); notify(`${metaFor(t)?.displayName ?? t} added`); }}
          onRemove={(t) => { d.removeObjectType(t); notify("Removed", d.undo); }}
          onAddChart={(t) => d.addWidget(newWidget(metaFor(t)))}
        />

        <main className="canvas">
          <div className="canvas-bar">
            <span className="canvas-bar-label">Applies to everything</span>
            {primaryType && metaFor(primaryType) && (
              <FilterEditor
                compact
                meta={metaFor(primaryType)}
                filters={dashboardFilters}
                onChange={(fn) => d.commit((s) => { s.filters = s.filters ?? []; fn(s.filters); })}
              />
            )}
            {crossFilter && (
              <span className="fchip cross">
                <span className="fchip-body">
                  <b>{crossFilter.label}</b>
                  <em>{crossFilter.value}</em>
                </span>
                <button className="fchip-x" onClick={() => setCrossFilter(null)}>×</button>
              </span>
            )}
          </div>

          <div className="grid">
            {d.spec.widgets.map((w) => (
              <WidgetTile
                key={w.id}
                meta={metaFor(w.objectType)}
                widget={w}
                selected={w.id === d.selectedId}
                crossFilter={crossFilter}
                onCrossFilter={setCrossFilter}
                onSelect={d.setSelectedId}
                onDragStart={(id) => (dragId.current = id)}
                onDragOver={(over) => {
                  if (dragId.current && dragId.current !== over) d.moveWidget(dragId.current, over);
                }}
              />
            ))}
            <button
              className="add"
              onClick={() => {
                const meta = metaFor(primaryType);
                if (meta) d.addWidget(newWidget(meta));
              }}
            >
              <span className="add-plus">+</span>
              New chart
            </button>
          </div>
        </main>

        <Inspector
          meta={d.selected ? metaFor(d.selected.objectType) : null}
          widget={d.selected}
          onChange={d.updateWidget}
          onDuplicate={(id) => { d.duplicateWidget(id); notify("Duplicated"); }}
          onRemove={(id) => { d.removeWidget(id); notify("Chart removed", d.undo); }}
        />
      </div>

      <SpecDrawer d={d} drawer={drawer} setDrawer={setDrawer} notify={notify} />

      {toast && (
        <div className="toast on">
          {toast.message}
          {toast.undo && (
            <button className="toast-undo" onClick={() => { toast.undo(); setToast(null); }}>Undo</button>
          )}
        </div>
      )}
    </>
  );
}

function SpecDrawer({ d, drawer, setDrawer, notify }) {
  return (
    <>
      <Drawer open={drawer === "spec"} title="Dashboard definition" onClose={() => setDrawer(null)}>
        <p className="drawer-note">
          The whole dashboard, saved as JSON. No SQL and no property names baked into code —
          only ontology references the query layer compiles into OSDK calls.
        </p>
        <pre className="code">{JSON.stringify(d.spec, null, 2)}</pre>
      </Drawer>

      <Drawer open={drawer === "versions"} title="History" onClose={() => setDrawer(null)}>
        <p className="drawer-note">
          Editing saves a draft continuously. Sharing takes a snapshot — that is what other
          people see.
        </p>
        {d.dirty && (
          <div className="ver current">
            <div className="ver-n">—</div>
            <div className="ver-main">
              <div className="ver-label">Working draft</div>
              <div className="ver-meta">Only you can see this</div>
            </div>
          </div>
        )}
        {!d.versions.length && !d.dirty && <div className="empty">Nothing shared yet.</div>}
        {d.versions.map((v) => (
          <div className={v.version === d.publishedVersion ? "ver current" : "ver"} key={v.version}>
            <div className="ver-n">v{v.version}</div>
            <div className="ver-main">
              <div className="ver-label">Version {v.version}</div>
              <div className="ver-meta">
                {v.by} · {new Date(v.at).toLocaleString()}
                {v.version === d.publishedVersion ? " · live" : ""}
              </div>
            </div>
            <button
              className="btn"
              onClick={() => { d.restore(v.version); setDrawer(null); notify(`Restored v${v.version}`, d.undo); }}
            >
              Restore
            </button>
          </div>
        ))}
      </Drawer>
    </>
  );
}
