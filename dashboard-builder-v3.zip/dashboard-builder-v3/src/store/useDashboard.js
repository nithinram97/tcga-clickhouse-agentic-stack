import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { emptySpec, normalize } from "../lib/spec.js";

const clone = (o) => JSON.parse(JSON.stringify(o));
const KEY = "dashboard:v3";

/**
 * State, history and persistence.
 *
 * Undo covers every edit including deletion, so nothing in the UI needs a
 * confirmation dialog. (Nielsen: user control and freedom — an obvious exit
 * beats a modal asking "are you sure".)
 */
export function useDashboard(metaFor) {
  const [spec, setSpec] = useState(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return JSON.parse(raw);
    } catch {}
    return emptySpec();
  });
  const [selectedId, setSelectedId] = useState(null);
  const [dirty, setDirty] = useState(false);
  const [versions, setVersions] = useState(() => {
    try { return JSON.parse(localStorage.getItem(`${KEY}:versions`) || "[]"); } catch { return []; }
  });
  const undoStack = useRef([]);
  const redoStack = useRef([]);
  const timer = useRef(null);

  useEffect(() => {
    if (!dirty) return;
    clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      try { localStorage.setItem(KEY, JSON.stringify(spec)); } catch {}
    }, 700);
    return () => clearTimeout(timer.current);
  }, [spec, dirty]);

  const commit = useCallback((mutator, { history = true } = {}) => {
    setSpec((prev) => {
      if (history) {
        undoStack.current.push(clone(prev));
        if (undoStack.current.length > 60) undoStack.current.shift();
        redoStack.current = [];
      }
      const next = clone(prev);
      mutator(next);
      next.widgets.forEach((w) => normalize(metaFor(w.objectType), w));
      return next;
    });
    setDirty(true);
  }, [metaFor]);

  const updateWidget = useCallback((id, mutator) =>
    commit((d) => {
      const w = d.widgets.find((x) => x.id === id);
      if (w) mutator(w, d);
    }), [commit]);

  const addWidget = useCallback((widget) => {
    commit((d) => {
      d.widgets.push(widget);
      if (!d.objectTypes.includes(widget.objectType)) d.objectTypes.push(widget.objectType);
    });
    setSelectedId(widget.id);
  }, [commit]);

  const addWidgets = useCallback((widgets) => {
    commit((d) => {
      widgets.forEach((w) => {
        d.widgets.push(w);
        if (!d.objectTypes.includes(w.objectType)) d.objectTypes.push(w.objectType);
      });
    });
  }, [commit]);

  const removeWidget = useCallback((id) => {
    commit((d) => { d.widgets = d.widgets.filter((w) => w.id !== id); });
    setSelectedId((c) => (c === id ? null : c));
  }, [commit]);

  const duplicateWidget = useCallback((id) => {
    let newId;
    commit((d) => {
      const i = d.widgets.findIndex((w) => w.id === id);
      if (i < 0) return;
      const copy = clone(d.widgets[i]);
      copy.id = `${id}_c${Math.random().toString(36).slice(2, 6)}`;
      newId = copy.id;
      d.widgets.splice(i + 1, 0, copy);
    });
    setTimeout(() => newId && setSelectedId(newId), 0);
  }, [commit]);

  const moveWidget = useCallback((fromId, toId) =>
    commit((d) => {
      const f = d.widgets.findIndex((w) => w.id === fromId);
      const t = d.widgets.findIndex((w) => w.id === toId);
      if (f < 0 || t < 0 || f === t) return;
      d.widgets.splice(t, 0, d.widgets.splice(f, 1)[0]);
    }), [commit]);

  const addObjectType = useCallback((apiName) =>
    commit((d) => {
      if (!d.objectTypes.includes(apiName)) d.objectTypes.push(apiName);
    }), [commit]);

  const removeObjectType = useCallback((apiName) =>
    commit((d) => {
      d.objectTypes = d.objectTypes.filter((t) => t !== apiName);
      d.widgets = d.widgets.filter((w) => w.objectType !== apiName);
    }), [commit]);

  const setTitle = useCallback((t) => commit((d) => { d.title = t; }), [commit]);

  const undo = useCallback(() => {
    const prev = undoStack.current.pop();
    if (!prev) return false;
    setSpec((cur) => { redoStack.current.push(clone(cur)); return prev; });
    setDirty(true);
    return true;
  }, []);

  const redo = useCallback(() => {
    const next = redoStack.current.pop();
    if (!next) return false;
    setSpec((cur) => { undoStack.current.push(clone(cur)); return next; });
    setDirty(true);
    return true;
  }, []);

  const publish = useCallback(() => {
    const entry = {
      version: (versions[0]?.version ?? 0) + 1,
      at: new Date().toISOString(),
      by: "you",
      spec: clone(spec)
    };
    const next = [entry, ...versions];
    setVersions(next);
    try { localStorage.setItem(`${KEY}:versions`, JSON.stringify(next)); } catch {}
    setDirty(false);
    return entry;
  }, [spec, versions]);

  const restore = useCallback((version) => {
    const found = versions.find((v) => v.version === version);
    if (found) commit((d) => Object.assign(d, clone(found.spec)));
  }, [versions, commit]);

  const selected = useMemo(
    () => spec.widgets.find((w) => w.id === selectedId) ?? null,
    [spec, selectedId]
  );

  return {
    spec, selected, selectedId, setSelectedId, dirty, versions,
    publishedVersion: versions[0]?.version ?? 0,
    commit, updateWidget, addWidget, addWidgets, removeWidget, duplicateWidget,
    moveWidget, addObjectType, removeObjectType, setTitle,
    undo, redo, publish, restore
  };
}
