import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import { DataProviderContext } from "./data/provider.js";
import { createMockProvider } from "./data/mockProvider.js";
import demoOntology from "./config/demo-ontology.json";
import "./styles.css";

/**
 * SWAP THIS LINE FOR REAL DATA.
 *
 *   import { createOsdkProvider } from "./data/osdkProvider.js";
 *   import { createClient } from "@osdk/client";
 *   import { createPublicOauthClient } from "@osdk/oauth";
 *   import * as Ontology from "@your-org/generated-sdk";
 *
 *   const auth = createPublicOauthClient(CLIENT_ID, FOUNDRY_URL, REDIRECT_URL);
 *   const client = createClient(FOUNDRY_URL, ONTOLOGY_RID, auth);
 *   const provider = createOsdkProvider(client, Ontology);
 *
 * Nothing else in the app changes. No component knows which provider is in use.
 */
const provider = createMockProvider(demoOntology);

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <DataProviderContext.Provider value={provider}>
      <App />
    </DataProviderContext.Provider>
  </React.StrictMode>
);
