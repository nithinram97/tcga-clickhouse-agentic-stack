# Dashboard builder — Vega-Lite

A React + Vite prototype of a dashboard builder for non-technical users, backed by a
Palantir Ontology / OSDK query layer. Charts are rendered with **Vega-Lite** via
react-vega, with click-to-cross-filter across tiles.

The whole product is a **JSON spec**. The builder writes it, the renderer reads it, and
the spec holds no SQL — only ontology references that compile into a single OSDK
aggregate call per chart.

## Run

```bash
npm install
npm run dev
```

## What works

- Pick one or more object types (left rail)
- Compose charts from three controls: source, group by, measure
- Multiple measures on one chart (bar + line, shared or independent axis)
- Split by a second dimension (stacked or side by side)
- Drag to reorder, resize to ¼ / ½ / full width
- Draft autosave, publish to an immutable version, restore an old version
- Undo/redo (Cmd/Ctrl+Z, Cmd/Ctrl+Shift+Z)
- **Click a bar to cross-filter every other chart**; the active filter appears as a
  removable chip in the filter bar
- "View spec" shows the live JSON; the inspector shows both the compiled OSDK call and
  the generated Vega-Lite spec

## Layout

```
src/
  ontology/ontology.js      Object types, properties, legal grouping strategies
  lib/spec.js               Spec shape, defaults, normalize()
  lib/query.js              MOCK data — replace with OSDK
  lib/osdk.js               spec → aggregate args + snippet
  lib/api.js                Persistence seam (localStorage → your API)
  store/useDashboard.js     State, undo/redo, autosave, versions
  components/               TopBar, SourceRail, Canvas, WidgetTile, Inspector, Drawer
  lib/vegaSpec.js           widget + data → Vega-Lite spec
  lib/theme.js              One Vega config carrying the app's design tokens
  components/charts/        Registry: VegaChart (bar/line/donut), table, kpi
```

## Wiring it up for real

**1. Ontology metadata.** Replace `src/ontology/ontology.js` with metadata from your
generated SDK. Every picker derives its options from this, so correct metadata means
the UI can only build valid queries.

**2. Queries.** Replace `queryData` in `src/lib/query.js` with a real call, keeping the
return shape `{ keys, stacked, series: [{ name, chart, axis, values }] }`.
`aggregateArgs()` in `lib/osdk.js` already produces the arguments.

Initialise the OSDK client with the **end user's token**, not a service token. If your
API proxies queries with a service account, Foundry's row-level permissions stop
protecting anything and every user sees every row.

**3. Persistence.** Point the four functions in `src/lib/api.js` at your Express +
Postgres service:

```sql
create table dashboards (
  id uuid primary key,
  slug text unique not null,
  title text not null,
  draft_spec jsonb not null,
  published_version int,
  owner_id text not null,
  updated_at timestamptz default now()
);

create table dashboard_versions (
  dashboard_id uuid references dashboards(id) on delete cascade,
  version int not null,
  spec jsonb not null,
  label text,
  created_by text not null,
  created_at timestamptz default now(),
  primary key (dashboard_id, version)
);
```

Keep dashboard metadata in Postgres, not ClickHouse or a Foundry object — specs are
edited in small increments constantly, which is what those two handle worst.

## Design decisions worth keeping

**`normalize()` in `lib/spec.js`.** Users edit freely, so widgets reach states no
individual handler anticipated (a measure pointing at a property the new object type
lacks). Rather than defend in every handler, the renderer accepts any spec and repairs
it. This exists because the earlier prototype crashed on exactly that.

**Availability over validation.** Incompatible chart types are disabled, not hidden and
not rejected after the fact. A donut turns off above six groups.

**Split-by and multi-measure are mutually exclusive.** Two measures each split three ways
is six stacks per bar. Loosen it in `normalize()` if you disagree.

**Draft vs published.** Autosave writes the draft; Publish snapshots a version. Without
the split, every drag becomes a version and history is useless.

## Not built

- **Link traversal** (`Order → customer.country`). The `path` field is reserved in the
  spec. Design it in early — retrofitting means migrating every saved spec.
- **Filter picker.** The filter bar is static.
- **Cross-object-type charts.** OSDK can't do this in one call; it needs two queries and
  a client-side join, and users will happily build charts that look fine and mean
  nothing. Prefer link traversal.
- **Real grid layout.** Reordering is drag-to-swap. Swap in `react-grid-layout` and have
  it emit a `layout[]` array into the spec.


## How Vega-Lite is used here

**The specs are the product.** `lib/vegaSpec.js` compiles a widget into a Vega-Lite
spec; the inspector shows you the result. Those specs are portable — they render in any
Vega host, including Foundry Workshop, so a dashboard built here can be viewed without
this React app.

**OSDK owns the numbers, Vega-Lite owns the pixels.** Nothing here uses Vega-Lite's own
`aggregate` or `bin` transforms, because the data arrives already aggregated. Two
aggregation layers disagreeing is the standard way this architecture goes wrong.

**Cross-filtering is lifted into React, not left to Vega.** Vega-Lite's elegant
cross-filter examples work because they are one spec using `repeat` or `concat`. These
widgets are separate specs in separate tiles, so a `sel_tuple` signal listener in
`VegaChart.jsx` pushes the selection into React state, and every tile re-queries. In the
real build that state becomes a `.where()` clause on the OSDK call — replace
`crossFilterFactor` in `lib/query.js`, which currently just damps the mock values so the
effect is visible.

The originating widget is deliberately not filtered by its own selection. Without that
exception, clicking a bar makes every other bar in that chart vanish.

**Theme lives in one place.** `lib/theme.js` is a single Vega config applied to every
chart. Restyling is one file, not every widget type.

**KPI and table are not Vega.** A single number does not need a visualization grammar,
and an HTML table wraps, sorts and copies better than anything Vega would draw.

## The bundle cost, honestly

Vega is around 300 kB gzipped — roughly six times the rest of the app. `ChartRenderer`
lazy-loads it so it does not block first paint, and a dashboard of only KPIs and tables
never downloads it. But if bundle size is a hard constraint, this is the tradeoff you
are accepting in exchange for portable specs and declarative selection.

## Verified

- Every widget × every legal chart type × with and without a cross-filter: 18 generated
  specs compile to Vega with marks emitted
- The `sel_tuple` selection signal is present on selectable charts
- Dual-axis combos emit `resolve.scale.y: independent`
