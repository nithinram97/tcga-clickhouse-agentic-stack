import { useCallback, useEffect, useRef, useState } from "react";
import { initialSpec, normalizeSpec, newWidget } from "../lib/spec.js";
import { loadDraft, saveDraft, publish as publishApi, listVersions } from "../lib/api.js";

const DASHBOARD_ID = "demo";
const clone = (o) => JSON.parse(JSON.stringify(o));

export function useDashboard() {
  const [spec, setSpec] = useState(() => normalizeSpec(initialSpec()));
  const [selectedId, setSelectedId] = useState("w1");
  const [dirty, setDirty] = useState(true);
  const [publishedVersion, setPublishedVersion] = useState(0);
  const [versions, setVersions] = useState([]);
  const undoStack = useRef([]);
  const redoStack = useRef([]);
  const saveTimer = useRef(null);

  useEffect(() => {
    (async () => {
      const draft = await loadDraft(DASHBOARD_ID);
      if (draft) setSpec(normalizeSpec(draft));
      const v = await listVersions(DASHBOARD_ID);
      setVersions(v);
      if (v[0]) setPublishedVersion(v[0].version);
    })();
  }, []);

  // Debounced autosave to the draft, never to a version.
  useEffect(() => {
    if (!dirty) return;
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => saveDraft(DASHBOARD_ID, spec), 800);
    return () => clearTimeout(saveTimer.current);
  }, [spec, dirty]);

  const commit = useCallback((mutator) => {
    setSpec((prev) => {
      undoStack.current.push(clone(prev));
      if (undoStack.current.length > 50) undoStack.current.shift();
      redoStack.current = [];
      const next = clone(prev);
      mutator(next);
      return normalizeSpec(next);
    });
    setDirty(true);
  }, []);

  const updateWidget = useCallback(
    (id, mutator) =>
      commit((draft) => {
        const w = draft.widgets.find((x) => x.id === id);
        if (w) mutator(w, draft);
      }),
    [commit]
  );

  const addWidget = useCallback(() => {
    let id;
    commit((draft) => {
      const w = newWidget(draft, draft.sources[0].id);
      id = w.id;
      draft.widgets.push(w);
    });
    setTimeout(() => id && setSelectedId(id), 0);
  }, [commit]);

  const duplicateWidget = useCallback(
    (wid) => {
      let id;
      commit((draft) => {
        const i = draft.widgets.findIndex((x) => x.id === wid);
        if (i < 0) return;
        const copy = clone(draft.widgets[i]);
        copy.id = `${wid}_c${Date.now().toString(36).slice(-4)}`;
        copy.title = `${copy.title} (copy)`;
        id = copy.id;
        draft.widgets.splice(i + 1, 0, copy);
      });
      setTimeout(() => id && setSelectedId(id), 0);
    },
    [commit]
  );

  const removeWidget = useCallback(
    (wid) => {
      commit((draft) => {
        draft.widgets = draft.widgets.filter((x) => x.id !== wid);
      });
      setSelectedId((cur) => (cur === wid ? null : cur));
    },
    [commit]
  );

  const moveWidget = useCallback(
    (fromId, toId) =>
      commit((draft) => {
        const from = draft.widgets.findIndex((w) => w.id === fromId);
        const to = draft.widgets.findIndex((w) => w.id === toId);
        if (from < 0 || to < 0 || from === to) return;
        draft.widgets.splice(to, 0, draft.widgets.splice(from, 1)[0]);
      }),
    [commit]
  );

  const addSource = useCallback(
    (objectType) =>
      commit((draft) => {
        if (draft.sources.some((s) => s.objectType === objectType)) return;
        draft.sources.push({
          id: `s_${objectType.toLowerCase().slice(0, 3)}`,
          objectType,
          alias: `${objectType}s`
        });
      }),
    [commit]
  );

  const undo = useCallback(() => {
    const prev = undoStack.current.pop();
    if (!prev) return;
    setSpec((cur) => {
      redoStack.current.push(clone(cur));
      return normalizeSpec(prev);
    });
    setDirty(true);
  }, []);

  const redo = useCallback(() => {
    const next = redoStack.current.pop();
    if (!next) return;
    setSpec((cur) => {
      undoStack.current.push(clone(cur));
      return normalizeSpec(next);
    });
    setDirty(true);
  }, []);

  const publish = useCallback(async () => {
    const entry = await publishApi(DASHBOARD_ID, spec);
    setVersions((v) => [entry, ...v]);
    setPublishedVersion(entry.version);
    setDirty(false);
    return entry;
  }, [spec]);

  const restore = useCallback(
    (version) => {
      const found = versions.find((v) => v.version === version);
      if (!found) return;
      commit((draft) => {
        Object.assign(draft, clone(found.spec));
      });
    },
    [versions, commit]
  );

  return {
    spec,
    selectedId,
    setSelectedId,
    dirty,
    versions,
    publishedVersion,
    updateWidget,
    addWidget,
    duplicateWidget,
    removeWidget,
    moveWidget,
    addSource,
    commit,
    undo,
    redo,
    publish,
    restore
  };
}
