import { useCallback, useEffect, useState } from "react";
import { useDashboard } from "./store/useDashboard.js";
import TopBar from "./components/TopBar.jsx";
import SourceRail from "./components/SourceRail.jsx";
import Canvas from "./components/Canvas.jsx";
import Inspector from "./components/Inspector.jsx";
import Drawer from "./components/Drawer.jsx";
import Toast from "./components/Toast.jsx";

export default function App() {
  const d = useDashboard();
  const [drawer, setDrawer] = useState(null);
  const [toast, setToast] = useState("");
  // Cross-filter is view state, not part of the saved spec: it is what the
  // reader is looking at right now, not what the author configured.
  const [crossFilter, setCrossFilter] = useState(null);

  const notify = useCallback((msg) => {
    setToast(msg);
    setTimeout(() => setToast(""), 1900);
  }, []);

  useEffect(() => {
    const onKey = (e) => {
      if (!(e.metaKey || e.ctrlKey) || e.key.toLowerCase() !== "z") return;
      e.preventDefault();
      e.shiftKey ? d.redo() : d.undo();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [d]);

  const selected = d.spec.widgets.find((w) => w.id === d.selectedId) || null;

  return (
    <>
      <TopBar
        spec={d.spec}
        dirty={d.dirty}
        publishedVersion={d.publishedVersion}
        onUndo={d.undo}
        onRedo={d.redo}
        onSpec={() => setDrawer("spec")}
        onVersions={() => setDrawer("versions")}
        onPublish={async () => {
          if (!d.dirty) return notify("Nothing new to publish");
          const e = await d.publish();
          notify(`Published v${e.version}`);
        }}
      />

      <div className="shell">
        <SourceRail
          spec={d.spec}
          onAddSource={(t) => {
            d.addSource(t);
            notify(`${t} added`);
          }}
        />
        <Canvas
          spec={d.spec}
          selectedId={d.selectedId}
          onSelect={d.setSelectedId}
          onAdd={() => {
            d.addWidget();
            notify("Chart added");
          }}
          onMove={d.moveWidget}
          onToast={notify}
          crossFilter={crossFilter}
          onCrossFilter={(cf) => {
            setCrossFilter(cf);
            if (cf) notify(`Filtered to ${cf.label}: ${cf.value}`);
          }}
        />
        <Inspector
          spec={d.spec}
          widget={selected}
          onChange={d.updateWidget}
          onDuplicate={(id) => {
            d.duplicateWidget(id);
            notify("Chart duplicated");
          }}
          onRemove={(id) => {
            d.removeWidget(id);
            notify("Chart removed");
          }}
        />
      </div>

      <Drawer
        open={drawer === "spec"}
        title="Dashboard spec"
        onClose={() => setDrawer(null)}
      >
        <p className="drawer-note">
          This is the whole saved artefact. It holds no SQL — only ontology references the backend
          compiles into OSDK aggregations.
        </p>
        <pre className="code">{JSON.stringify(d.spec, null, 2)}</pre>
      </Drawer>

      <Drawer
        open={drawer === "versions"}
        title="Version history"
        onClose={() => setDrawer(null)}
      >
        <p className="drawer-note">
          Editing writes to a draft. Publishing takes a snapshot — that is what viewers see.
        </p>
        {d.dirty && (
          <div className="ver current">
            <div className="ver-n">—</div>
            <div className="ver-main">
              <div className="ver-label">Working draft</div>
              <div className="ver-meta">Unpublished · only visible to you</div>
            </div>
          </div>
        )}
        {d.versions.length === 0 && !d.dirty && (
          <div className="empty">Nothing published yet.</div>
        )}
        {d.versions.map((v) => (
          <div
            className={v.version === d.publishedVersion ? "ver current" : "ver"}
            key={v.version}
          >
            <div className="ver-n">v{v.version}</div>
            <div className="ver-main">
              <div className="ver-label">{v.label}</div>
              <div className="ver-meta">
                {v.by} · {new Date(v.at).toLocaleString()}
                {v.version === d.publishedVersion ? " · live" : ""}
              </div>
            </div>
            <button
              className="btn"
              onClick={() => {
                d.restore(v.version);
                setDrawer(null);
                notify(`Restored v${v.version} into the draft`);
              }}
            >
              Restore
            </button>
          </div>
        ))}
      </Drawer>

      <Toast message={toast} />
    </>
  );
}
