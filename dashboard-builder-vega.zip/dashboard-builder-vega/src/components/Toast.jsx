export default function Toast({ message }) {
  return <div className={message ? "toast on" : "toast"}>{message}</div>;
}
