import { useEffect } from "react";

export default function Drawer({ open, title, onClose, children }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <>
      <div className={open ? "scrim on" : "scrim"} onClick={onClose} />
      <div className={open ? "drawer open" : "drawer"}>
        <div className="drawer-head">
          <strong>{title}</strong>
          <button className="btn icon" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </div>
        <div className="drawer-body">{open && children}</div>
      </div>
    </>
  );
}
