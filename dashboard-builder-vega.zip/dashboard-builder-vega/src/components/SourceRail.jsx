import { useState } from "react";
import { ONTOLOGY, objectTypes } from "../ontology/ontology.js";

export default function SourceRail({ spec, onAddSource }) {
  const [open, setOpen] = useState(() => new Set(spec.sources.map((s) => s.id)));

  const toggle = (id) =>
    setOpen((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const missing = objectTypes().find((k) => !spec.sources.some((s) => s.objectType === k));

  return (
    <aside className="rail">
      <div className="rail-head">
        <span>Object types</span>
        <button
          className="btn icon"
          onClick={() => missing && onAddSource(missing)}
          disabled={!missing}
          title="Add object type"
        >
          +
        </button>
      </div>

      {spec.sources.map((s) => {
        const o = ONTOLOGY[s.objectType];
        const used = spec.widgets.filter((w) => w.sourceId === s.id).length;
        return (
          <div key={s.id} className={open.has(s.id) ? "src on" : "src"}>
            <div className="src-row" onClick={() => toggle(s.id)}>
              <span className="src-dot" />
              <span className="src-name">{o.label}</span>
              <span className="src-count">{used}</span>
            </div>
            <div className="props">
              {o.properties.map((p) => (
                <div className="prop" key={p.api}>
                  <span className="ptype">{p.type.slice(0, 3)}</span>
                  {p.label}
                </div>
              ))}
              {o.links.map((l) => (
                <div className="prop" key={l.api}>
                  <span className="ptype">link</span>
                  {l.label}
                </div>
              ))}
            </div>
          </div>
        );
      })}

      <div className="rail-note">
        Properties come from the ontology. Charts can only use what is listed here, so a broken
        query is not something you can build.
      </div>
    </aside>
  );
}
