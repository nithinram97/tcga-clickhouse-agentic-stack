import {
  ONTOLOGY,
  AGGS,
  NUMERIC,
  strategiesFor,
  propOf,
  measuresFor,
  groupablesFor
} from "../ontology/ontology.js";
import { objectTypeOf } from "../lib/spec.js";
import { queryData } from "../lib/query.js";
import { snippetFor } from "../lib/osdk.js";
import { buildSpec } from "../lib/vegaSpec.js";

const CHART_ICONS = { bar: "▤", line: "◺", donut: "◐", table: "☰", kpi: "#" };

/** Config is identical on every chart and data is long — noise in the inspector. */
const forDisplay = ({ config, $schema, data, ...rest }) => ({
  ...rest,
  data: { values: `… ${data?.values?.length ?? 0} rows` }
});

export default function Inspector({ spec, widget, onChange, onDuplicate, onRemove }) {
  if (!widget)
    return (
      <aside className="inspector">
        <div className="insp-head">
          <span className="insp-title">Nothing selected</span>
        </div>
        <div className="empty">Pick a chart on the canvas to change what it shows.</div>
      </aside>
    );

  const objectType = objectTypeOf(spec, widget);
  const obj = ONTOLOGY[objectType];
  const measures = measuresFor(objectType);
  const groupables = groupablesFor(objectType);
  const gp = widget.groupBy ? propOf(objectType, widget.groupBy.property) : null;
  const strategies = gp ? strategiesFor(gp.type) : [];
  const data = queryData(spec, widget);
  const cells = data.keys.length * data.series.length;
  const multi = widget.series.length > 1;
  const primary = widget.series[0].chart;

  // Availability, not validation. A disabled control teaches; an error message
  // after the fact does not.
  const types = [
    { t: "bar", ok: !!widget.groupBy },
    { t: "line", ok: !!widget.groupBy },
    { t: "donut", ok: !!widget.groupBy && !multi && !widget.breakdown && data.keys.length <= 6 },
    { t: "table", ok: true },
    { t: "kpi", ok: !widget.groupBy }
  ];

  const splitOptions = groupables.filter(
    (p) => p.type !== "timestamp" && (!widget.groupBy || p.api !== widget.groupBy.property)
  );

  const set = (mutator) => onChange(widget.id, mutator);

  return (
    <aside className="inspector">
      <div className="insp-head">
        <span className="insp-title">Chart settings</span>
        <button className="btn icon" onClick={() => onDuplicate(widget.id)} title="Duplicate">
          ⧉
        </button>
      </div>

      <div className="insp-body">
        <div className="field">
          <label htmlFor="f-title">Title</label>
          <input
            id="f-title"
            className="ctl"
            value={widget.title}
            onChange={(e) => set((w) => (w.title = e.target.value || "Untitled chart"))}
          />
        </div>

        <div className="field">
          <label htmlFor="f-src">Object type</label>
          <select
            id="f-src"
            className="ctl"
            value={widget.sourceId}
            onChange={(e) =>
              set((w, draft) => {
                w.sourceId = e.target.value;
                const o = ONTOLOGY[draft.sources.find((s) => s.id === w.sourceId).objectType];
                const g = o.properties[0];
                const num = o.properties.find((p) => NUMERIC.includes(p.type));
                w.groupBy = { property: g.api, strategy: strategiesFor(g.type)[0] };
                w.breakdown = null;
                w.series = [
                  {
                    property: num ? num.api : null,
                    fn: num ? "sum" : "count",
                    chart: "bar",
                    axis: "left"
                  }
                ];
              })
            }
          >
            {spec.sources.map((s) => (
              <option key={s.id} value={s.id}>
                {ONTOLOGY[s.objectType].label}
              </option>
            ))}
          </select>
        </div>

        <div className="field">
          <label htmlFor="f-group">Group by</label>
          <select
            id="f-group"
            className="ctl"
            value={widget.groupBy?.property || ""}
            onChange={(e) =>
              set((w) => {
                if (!e.target.value) {
                  w.groupBy = null;
                  w.breakdown = null;
                } else {
                  const p = propOf(objectType, e.target.value);
                  w.groupBy = { property: p.api, strategy: strategiesFor(p.type)[0] };
                }
              })
            }
          >
            <option value="">Nothing — one total</option>
            {groupables.map((p) => (
              <option key={p.api} value={p.api}>
                {p.label}
              </option>
            ))}
          </select>
        </div>

        {widget.groupBy && (
          <div className="field">
            <label htmlFor="f-strat">Grouped</label>
            <select
              id="f-strat"
              className="ctl"
              value={strategies.findIndex(
                (s) =>
                  s.kind === widget.groupBy.strategy.kind &&
                  (!s.unit || s.unit === widget.groupBy.strategy.unit)
              )}
              onChange={(e) => set((w) => (w.groupBy.strategy = strategies[+e.target.value]))}
            >
              {strategies.map((s, i) => (
                <option key={s.label} value={i}>
                  {s.label}
                </option>
              ))}
            </select>
          </div>
        )}

        <div className="field">
          <label>{multi ? "Measures" : "Measure"}</label>
          {widget.series.map((s, i) => (
            <div className="mrow" key={i}>
              <select
                className="ctl m-prop"
                value={s.property || ""}
                onChange={(e) =>
                  set((w) => {
                    const t = w.series[i];
                    if (e.target.value) {
                      t.property = e.target.value;
                      if (t.fn === "count") t.fn = "sum";
                    } else {
                      t.property = null;
                      t.fn = "count";
                    }
                  })
                }
              >
                <option value="">Number of records</option>
                {measures.map((p) => (
                  <option key={p.api} value={p.api}>
                    {p.label}
                  </option>
                ))}
              </select>

              <select
                className="ctl m-agg"
                disabled={!s.property}
                value={s.property ? s.fn : "count"}
                onChange={(e) => set((w) => (w.series[i].fn = e.target.value))}
              >
                {s.property ? (
                  AGGS.map((a) => (
                    <option key={a.fn} value={a.fn}>
                      {a.label}
                    </option>
                  ))
                ) : (
                  <option value="count">Count</option>
                )}
              </select>

              {multi && (
                <>
                  <select
                    className="ctl m-chart"
                    value={s.chart}
                    onChange={(e) => set((w) => (w.series[i].chart = e.target.value))}
                  >
                    <option value="bar">▤</option>
                    <option value="line">◺</option>
                  </select>
                  <button
                    className="m-del"
                    title="Remove measure"
                    onClick={() => set((w) => w.series.splice(i, 1))}
                  >
                    −
                  </button>
                </>
              )}
            </div>
          ))}

          {!widget.breakdown && widget.groupBy && widget.series.length < 3 && (
            <button
              className="addm"
              onClick={() =>
                set((w) => {
                  const used = w.series.map((s) => s.property);
                  const next = obj.properties.find(
                    (p) => NUMERIC.includes(p.type) && !used.includes(p.api)
                  );
                  w.series.push({
                    property: next ? next.api : null,
                    fn: next ? "sum" : "count",
                    chart: w.series.length === 1 ? "line" : "bar",
                    axis: "right"
                  });
                  if (["donut", "kpi"].includes(w.series[0].chart)) w.series[0].chart = "bar";
                })
              }
            >
              + Add measure
            </button>
          )}
        </div>

        {multi && (
          <div className="field">
            <label>Second measure axis</label>
            <div className="seg">
              {[
                { a: "left", label: "Same scale" },
                { a: "right", label: "Own scale" }
              ].map((o) => (
                <button
                  key={o.a}
                  className={widget.series[1].axis === o.a ? "on" : ""}
                  onClick={() => set((w) => w.series.slice(1).forEach((s) => (s.axis = o.a)))}
                >
                  {o.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {widget.groupBy && !multi && (
          <div className="field">
            <label htmlFor="f-split">Split by</label>
            <select
              id="f-split"
              className="ctl"
              value={widget.breakdown?.property || ""}
              onChange={(e) =>
                set((w) => {
                  if (!e.target.value) w.breakdown = null;
                  else {
                    w.breakdown = {
                      property: e.target.value,
                      strategy: { kind: "topValues" },
                      n: 3
                    };
                    w.stack = w.stack || "normal";
                    if (w.series[0].chart === "donut") w.series[0].chart = "bar";
                  }
                })
              }
            >
              <option value="">No split</option>
              {splitOptions.map((p) => (
                <option key={p.api} value={p.api}>
                  {p.label}
                </option>
              ))}
            </select>
          </div>
        )}

        {widget.breakdown && (
          <div className="field">
            <label>Split display</label>
            <div className="seg">
              {[
                { k: "normal", label: "Stacked" },
                { k: "none", label: "Side by side" }
              ].map((o) => (
                <button
                  key={o.k}
                  className={(widget.stack === "normal") === (o.k === "normal") ? "on" : ""}
                  onClick={() => set((w) => (w.stack = o.k))}
                >
                  {o.label}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="field">
          <label>Chart type</label>
          <div className="seg">
            {types.map((t) => (
              <button
                key={t.t}
                disabled={!t.ok}
                title={t.t}
                className={primary === t.t ? "on" : ""}
                onClick={() =>
                  set((w) =>
                    w.series.forEach((s, i) => {
                      if (i === 0 || t.t === "table" || t.t === "kpi") s.chart = t.t;
                    })
                  )
                }
              >
                {CHART_ICONS[t.t]}
              </button>
            ))}
          </div>
        </div>

        {cells > 24 && (
          <div className="hint">
            {data.keys.length} groups × {data.series.length} series is {cells} bars. Fewer split
            values, or a table, will read better.
          </div>
        )}
        {multi && widget.series[1].axis === "left" && (
          <div className="hint">
            These two measures share one scale. If their ranges differ a lot, switch the second to
            its own scale.
          </div>
        )}

        <div className="field">
          <label>Width</label>
          <div className="seg">
            {[
              { s: 1, label: "¼" },
              { s: 2, label: "½" },
              { s: 4, label: "Full" }
            ].map((o) => (
              <button
                key={o.s}
                className={widget.span === o.s ? "on" : ""}
                onClick={() => set((w) => (w.span = o.s))}
              >
                {o.label}
              </button>
            ))}
          </div>
        </div>

        <div className="divider" />
        <div className="sect-label">Runs against</div>
        <pre className="code">{snippetFor(spec, widget)}</pre>

        <div className="divider" />
        <div className="sect-label">Vega-Lite spec</div>
        <pre className="code">
          {JSON.stringify(forDisplay(buildSpec(widget, data)), null, 2)}
        </pre>

        <div className="divider" />
        <button className="btn danger full" onClick={() => onRemove(widget.id)}>
          Remove chart
        </button>
      </div>
    </aside>
  );
}
