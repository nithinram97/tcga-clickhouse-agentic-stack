import { useRef } from "react";
import WidgetTile from "./WidgetTile.jsx";
import FilterBar from "./FilterBar.jsx";

export default function Canvas({
  spec,
  selectedId,
  crossFilter,
  onCrossFilter,
  onSelect,
  onAdd,
  onMove,
  onToast
}) {
  const dragId = useRef(null);

  return (
    <main className="canvas">
      <FilterBar
        crossFilter={crossFilter}
        onClearCrossFilter={() => onCrossFilter(null)}
        onAdd={() => onToast("Filter picker — not in this prototype")}
      />
      <div className="grid">
        {spec.widgets.map((w) => (
          <WidgetTile
            key={w.id}
            spec={spec}
            widget={w}
            selected={w.id === selectedId}
            crossFilter={crossFilter}
            onCrossFilter={onCrossFilter}
            onSelect={onSelect}
            onDragStart={(id) => (dragId.current = id)}
            onDragOver={(overId) => {
              if (dragId.current && dragId.current !== overId) onMove(dragId.current, overId);
            }}
          />
        ))}
        <button className="add" onClick={onAdd}>
          <span className="add-plus">+</span>
          Add widget
        </button>
      </div>
    </main>
  );
}
