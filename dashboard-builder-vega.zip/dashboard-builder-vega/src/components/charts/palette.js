export const FILLS = [
  "var(--data-1)",
  "#7a6fd0",
  "var(--data-2)",
  "#c98b3f",
  "var(--data-3)",
  "#9aa4b4"
];
