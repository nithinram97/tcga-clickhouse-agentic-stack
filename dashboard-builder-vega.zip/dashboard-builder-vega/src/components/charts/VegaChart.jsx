import { useCallback, useEffect, useMemo, useRef } from "react";
import { VegaEmbed } from "react-vega";
import { buildSpec, SELECT_PARAM } from "../../lib/vegaSpec.js";

const OPTIONS = { actions: false, renderer: "svg" };

/**
 * Renders one widget with Vega-Lite.
 *
 * Selection crosses tile boundaries by lifting it into React state. Vega-Lite's
 * own cross-filtering only works within a single spec (repeat / concat), and our
 * widgets are separate specs in separate tiles — so this signal listener is the
 * bridge between them.
 */
export default function VegaChart({ widget, data, onSelect }) {
  const spec = useMemo(
    () => buildSpec(widget, data, { selectable: !!onSelect }),
    [widget, data, onSelect]
  );

  // Keep the callback in a ref so the signal listener never goes stale and we
  // do not have to re-embed the chart every time the parent re-renders.
  const cb = useRef(onSelect);
  useEffect(() => {
    cb.current = onSelect;
  }, [onSelect]);

  const viewRef = useRef(null);

  const onEmbed = useCallback((result) => {
    const view = result?.view;
    if (!view) return;
    viewRef.current = view;
    const signal = `${SELECT_PARAM}_tuple`;
    try {
      // A point param named `sel` compiles to a `sel_tuple` signal carrying the
      // selected field values, or null once the selection is cleared.
      view.addSignalListener(signal, (_name, tuple) => {
        if (!cb.current) return;
        cb.current(tuple?.values?.[0] ?? null);
      });
    } catch {
      // Charts without a selection param (donut, single line) have no such
      // signal. Nothing to listen to, nothing to do.
    }
  }, []);

  const onError = useCallback((e) => {
    console.error("Vega render failed", e);
  }, []);

  return (
    <div className="vega-host">
      <VegaEmbed spec={spec} options={OPTIONS} onEmbed={onEmbed} onError={onError} />
    </div>
  );
}
