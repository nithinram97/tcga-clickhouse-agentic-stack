import { cell, fmt } from "../../lib/query.js";

export default function KpiChart({ spec, widget }) {
  return widget.series.map((s, i) => (
    <div key={i}>
      <div className="kpi-val mono">
        {s.fn !== "count" ? "$" : ""}
        {fmt(cell(spec, widget, s, "total", null, 0))}
      </div>
      <div className="kpi-delta">▲ 6.2% vs previous period</div>
    </div>
  ));
}
