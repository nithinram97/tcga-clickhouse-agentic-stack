import { fmt } from "../../lib/query.js";

export default function TableChart({ data }) {
  return (
    <table className="data-table">
      <thead>
        <tr>
          <th />
          {data.series.map((s, i) => (
            <th key={i}>{s.name.split(" of ").pop()}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {data.keys.slice(0, 5).map((k, i) => (
          <tr key={k}>
            <td>{k}</td>
            {data.series.map((s, si) => (
              <td key={si} className="mono num">
                {fmt(s.values[i])}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
