import { Suspense, lazy } from "react";
import TableChart from "./TableChart.jsx";
import KpiChart from "./KpiChart.jsx";

// Vega is ~300 kB gzipped, so it loads on demand rather than blocking first
// paint. Dashboards of only KPIs and tables never download it at all.
const VegaChart = lazy(() => import("./VegaChart.jsx"));

/**
 * Registry.
 *
 * KPI and table stay as plain markup on purpose — a single number does not need
 * a visualization grammar, and an HTML table wraps, sorts and copies better than
 * anything Vega would draw.
 */
const CHARTS = { bar: "vega", line: "vega", donut: "vega", table: TableChart, kpi: KpiChart };

export default function ChartRenderer({ spec, widget, data, onSelect }) {
  const entry = CHARTS[widget.series[0].chart] || "vega";

  if (entry === "vega") {
    return (
      <Suspense fallback={<div className="chart-loading" />}>
        <VegaChart widget={widget} data={data} onSelect={onSelect} />
      </Suspense>
    );
  }
  const Chart = entry;
  return <Chart spec={spec} widget={widget} data={data} />;
}
