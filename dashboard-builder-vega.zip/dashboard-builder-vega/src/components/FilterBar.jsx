export default function FilterBar({ crossFilter, onClearCrossFilter, onAdd }) {
  const filters = [
    { label: "Order date", value: "Last 90 days" },
    { label: "Region", value: "All" },
    { label: "Status", value: "Shipped" }
  ];
  return (
    <div className="filterbar">
      {filters.map((f) => (
        <div className="filter" key={f.label}>
          <span>{f.label}</span>
          <b>{f.value}</b>
        </div>
      ))}

      {crossFilter && (
        <div className="filter cross">
          <span>{crossFilter.label}</span>
          <b>{crossFilter.value}</b>
          <button onClick={onClearCrossFilter} aria-label="Clear cross-filter">✕</button>
        </div>
      )}

      <button className="btn" onClick={onAdd}>
        Add filter
      </button>
    </div>
  );
}
