export default function TopBar({ spec, dirty, publishedVersion, onSpec, onVersions, onPublish, onUndo, onRedo }) {
  return (
    <div className="topbar">
      <div className="brand">
        <div className="brand-mark" aria-hidden="true" />
        <div className="brand-name">Dashboard builder</div>
      </div>
      <div>
        <div className="doc-title">{spec.title}</div>
        <div className="doc-meta">
          {dirty
            ? "Draft · edited just now"
            : `Published v${publishedVersion} · a moment ago`}
        </div>
      </div>
      <div className="topbar-right">
        <span className={dirty ? "chip" : "chip live"}>
          {dirty ? "Unpublished changes" : `Live · v${publishedVersion}`}
        </span>
        <button className="btn icon" onClick={onUndo} title="Undo">↶</button>
        <button className="btn icon" onClick={onRedo} title="Redo">↷</button>
        <button className="btn" onClick={onSpec}>View spec</button>
        <button className="btn" onClick={onVersions}>History</button>
        <button className="btn primary" onClick={onPublish}>Publish</button>
      </div>
    </div>
  );
}
