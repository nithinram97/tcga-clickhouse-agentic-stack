/**
 * Mock ontology metadata.
 *
 * REPLACE THIS with real metadata from your OSDK-generated SDK. Everything the
 * builder offers the user is derived from this shape, so once it reflects your
 * real object types the pickers configure themselves.
 */
export const ONTOLOGY = {
  Order: {
    label: "Order",
    properties: [
      { api: "region", label: "Region", type: "string" },
      { api: "status", label: "Status", type: "string" },
      { api: "channel", label: "Channel", type: "string" },
      { api: "orderDate", label: "Order date", type: "timestamp" },
      { api: "revenue", label: "Revenue", type: "double" },
      { api: "itemCount", label: "Item count", type: "integer" }
    ],
    links: [{ api: "customer", label: "Customer", target: "Customer" }]
  },
  Customer: {
    label: "Customer",
    properties: [
      { api: "country", label: "Country", type: "string" },
      { api: "segment", label: "Segment", type: "string" },
      { api: "signupDate", label: "Signup date", type: "timestamp" },
      { api: "lifetimeValue", label: "Lifetime value", type: "double" }
    ],
    links: [{ api: "orders", label: "Orders", target: "Order" }]
  },
  Product: {
    label: "Product",
    properties: [
      { api: "category", label: "Category", type: "string" },
      { api: "unitPrice", label: "Unit price", type: "double" },
      { api: "inStock", label: "In stock", type: "boolean" }
    ],
    links: []
  }
};

export const NUMERIC = ["double", "integer"];

export const AGGS = [
  { fn: "sum", label: "Sum" },
  { fn: "avg", label: "Average" },
  { fn: "max", label: "Max" },
  { fn: "min", label: "Min" }
];

/**
 * The property's type decides which groupings are legal. This is what stops a
 * non-technical user building an invalid or catastrophic query: they are never
 * offered one.
 */
export function strategiesFor(type) {
  if (type === "timestamp")
    return [
      { kind: "duration", unit: "days", label: "by day" },
      { kind: "duration", unit: "weeks", label: "by week" },
      { kind: "duration", unit: "months", label: "by month" },
      { kind: "duration", unit: "quarters", label: "by quarter" }
    ];
  if (NUMERIC.includes(type))
    return [
      { kind: "fixedWidth", width: 100, label: "in bands of 100" },
      { kind: "exact", label: "exact value" }
    ];
  return [
    { kind: "exact", label: "exact" },
    { kind: "topValues", label: "top 10 only" }
  ];
}

export const objectTypes = () => Object.keys(ONTOLOGY);

export function propOf(objectType, api) {
  const o = ONTOLOGY[objectType];
  if (!o) return { api, label: api, type: "double" };
  return o.properties.find((p) => p.api === api) || { api, label: api, type: "double" };
}

export const hasProp = (objectType, api) =>
  ONTOLOGY[objectType].properties.some((p) => p.api === api);

export const measuresFor = (objectType) =>
  ONTOLOGY[objectType].properties.filter((p) => NUMERIC.includes(p.type));

export const groupablesFor = (objectType) => ONTOLOGY[objectType].properties;
