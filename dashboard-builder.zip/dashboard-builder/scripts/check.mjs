/**
 * Proves the app is ontology-agnostic.
 *
 * Runs the whole pipeline — metadata → suggestions → normalize → compile →
 * aggregate → Vega-Lite — against a schema invented here, sharing no property
 * name, object type or domain with the demo. If anything in src/ were coded for
 * a specific ontology, this would fail.
 */
import { compile } from "vega-lite";
import { createMockProvider } from "../src/data/mockProvider.js";
import { suggestWidgets } from "../src/lib/recommend.js";
import { newWidget, normalize, autoTitle, shapeOf } from "../src/lib/spec.js";
import { compileQuery, osdkSnippet } from "../src/lib/compile.js";
import { buildSpec } from "../src/lib/vegaSpec.js";
import { CHARTS, CHART_ORDER } from "../src/config/charts.js";
import { kindConfig, OPERATORS } from "../src/config/propertyTypes.js";
import demo from "../src/config/demo-ontology.json" with { type: "json" };

// A completely unrelated ontology: hospital logistics, odd types, a property
// kind the app must gracefully ignore.
const ALIEN = {
  objectTypes: [
    {
      apiName: "VaccineShipment",
      displayName: "Vaccine shipment",
      description: "Cold-chain delivery",
      primaryKey: "consignmentRef",
      properties: [
        { apiName: "consignmentRef", displayName: "Consignment ref", type: "string" },
        { apiName: "manufacturer", displayName: "Manufacturer", type: "string", sampleValues: ["Serum Institute", "BioNTech", "Bharat"] },
        { apiName: "coldChainBreached", displayName: "Cold chain breached", type: "boolean" },
        { apiName: "dispatchedAt", displayName: "Dispatched", type: "timestamp" },
        { apiName: "doseCount", displayName: "Doses", type: "long" },
        { apiName: "transitHours", displayName: "Transit hours", type: "float" },
        { apiName: "depotLocation", displayName: "Depot", type: "geopoint" },
        { apiName: "customsDocs", displayName: "Customs docs", type: "attachment" }
      ],
      links: []
    },
    {
      apiName: "ClinicSite",
      displayName: "Clinic site",
      primaryKey: "siteCode",
      properties: [
        { apiName: "siteCode", displayName: "Site code", type: "string" },
        { apiName: "district", displayName: "District", type: "string", sampleValues: ["North", "South", "Coastal", "Hill"] },
        { apiName: "staffCount", displayName: "Staff", type: "integer" },
        { apiName: "commissionedOn", displayName: "Commissioned", type: "date" }
      ],
      links: []
    }
  ]
};

let pass = 0, fail = 0;
const ok = (cond, label) => { cond ? pass++ : (fail++, console.log(`  FAIL ${label}`)); };

async function run(schema, name) {
  console.log(`\n── ${name} ──`);
  const provider = createMockProvider(schema);
  const list = await provider.listObjectTypes();
  ok(list.length === schema.objectTypes.length, "lists object types");

  for (const ot of list) {
    const meta = await provider.describeObjectType(ot.apiName);

    // Suggestions must be generated and must all render.
    const suggestions = suggestWidgets(meta);
    ok(suggestions.length > 0, `${ot.apiName}: produces suggestions`);

    for (const s of suggestions) {
      normalize(meta, s);
      ok(!!autoTitle(meta, s), `${ot.apiName}: auto title`);
      const q = compileQuery(meta, s, []);
      const data = await provider.aggregate(q);
      ok(data.keys.length > 0 && data.series.length > 0, `${ot.apiName}: returns data`);
      ok(osdkSnippet(meta, q).includes("aggregate"), `${ot.apiName}: emits OSDK`);

      // Every chart type this shape allows must compile to valid Vega.
      const shape = shapeOf(meta, s, data);
      for (const c of CHART_ORDER) {
        if (CHARTS[c].fits(shape) !== true) continue;
        const probe = { ...s, chart: c };
        if (!["bar", "column", "line", "area", "donut"].includes(c)) continue;
        try {
          const vl = buildSpec(probe, data, { selectable: true });
          const out = compile(vl);
          ok(!!out.spec.marks?.length, `${ot.apiName}/${c}: compiles`);
        } catch (e) {
          fail++; console.log(`  FAIL ${ot.apiName}/${c}: ${e.message}`);
        }
      }
    }

    // A blank widget must be buildable for any object type.
    const blank = normalize(meta, newWidget(meta));
    const bd = await provider.aggregate(compileQuery(meta, blank, []));
    ok(bd.series.length > 0, `${ot.apiName}: blank widget works`);

    // Every property must yield working filter operators and real values.
    for (const p of meta.properties) {
      const cfg = kindConfig(p.type);
      if (cfg.hidden) { ok(cfg.operators.length === 0, `${p.apiName}: excluded cleanly`); continue; }
      ok(cfg.operators.length > 0, `${p.apiName}: has operators`);
      for (const opName of cfg.operators) {
        const clause = OPERATORS[opName].build(p.apiName, ["x"]);
        ok(!!clause && typeof clause === "object", `${p.apiName}/${opName}: builds where`);
      }
      if (cfg.operators.includes("in")) {
        const vals = await provider.distinctValues(ot.apiName, p.apiName, 5);
        ok(vals.length > 0 && vals[0].value != null, `${p.apiName}: filter values`);
      }
    }

    // Styling: renames and colour overrides must reach the compiled spec.
    const styled = normalize(meta, newWidget(meta));
    const sd = await provider.aggregate(compileQuery(meta, styled, []));
    const first = sd.series[0].name;
    styled.style.labels = { [first]: "RENAMED" };
    styled.style.colors = { [first]: "#123456" };
    if (styled.chart !== "kpi") {
      const vl = buildSpec(styled, sd, {});
      const json = JSON.stringify(vl);
      ok(json.includes("RENAMED"), `${ot.apiName}: rename applied`);
      ok(json.includes("#123456"), `${ot.apiName}: colour applied`);
    }
  }
}

// Guard against ontology-specific code creeping back in.
import { readdirSync, readFileSync, statSync } from "fs";
import { join } from "path";
const BANNED = ["revenue", "region", "channel", "Order", "Customer", "segment", "itemCount"];
function walk(dir, out = []) {
  for (const f of readdirSync(dir)) {
    const p = join(dir, f);
    if (statSync(p).isDirectory()) walk(p, out);
    else if (/\.(js|jsx)$/.test(f)) out.push(p);
  }
  return out;
}
function checkHardcoding() {
  console.log("\n── no ontology-specific identifiers in src/ ──");
  for (const file of walk("src")) {
    const body = readFileSync(file, "utf8")
      .replace(/\/\*[\s\S]*?\*\//g, "")
      .replace(/^\s*\/\/.*$/gm, "");
    for (const term of BANNED) {
      const hit = new RegExp(`["'\`]${term}["'\`]|\\.${term}\\b`).test(body);
      ok(!hit, `${file} references "${term}"`);
    }
  }
}

await run(demo, "demo ontology (sales)");
await run(ALIEN, "alien ontology (vaccine logistics) — never seen by src/");
checkHardcoding();

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
