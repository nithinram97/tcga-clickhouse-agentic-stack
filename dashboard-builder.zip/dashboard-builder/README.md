# Dashboard builder

Self-service dashboards for non-technical users, on a Palantir Ontology / OSDK backend.

Two things drive everything here:

1. **The ontology is the only source of truth.** No object type, property name or
   domain concept is hardcoded anywhere in `src/`. Point it at a different ontology
   and the entire UI reconfigures itself.
2. **The chart definition reads as a sentence.** Not a form of labelled inputs.

```bash
npm install
npm run dev      # runs on the built-in demo ontology
npm run check    # proves the two claims above
```

### Switching to your real Foundry ontology

```bash
npm i @fdc9-skywiseperfodynamiclp/sdk @osdk/client @osdk/oauth @osdk/foundry
cp .env.example .env      # fill in from Developer Console
# set VITE_DATA_SOURCE=foundry
npm run dev
```

That is the whole switch — `src/data/bootstrap.js` picks the provider and the
persistence store from that one variable, and no component knows which it got.

The Foundry packages are in a private registry, so `vite.config.js` aliases any
that are absent to a stub. A checkout without access still builds and runs in
mock mode; if you set `VITE_DATA_SOURCE=foundry` without installing them, you
get an error naming the exact install command rather than a blank screen.

**Before the Foundry path runs, check one thing.** Your three Actions
(`[Dynamic LP] Create New Dashboard` / `Update dashboard` / `Delete Dashboard`)
have apiNames and parameter names that only appear on each Action's own page in
Developer Console. They live in a single `ACTIONS` block at the top of
`src/data/dashboardStore.js`. It throws a named error if an Action is not
exported by the SDK, so a wrong guess fails loudly.

---

## The interaction model

### The sentence builder

The chart definition is an English sentence whose nouns are clickable:

> Show **total revenue** for every **region** split by **channel**

Why this rather than a form or drag-and-drop shelves:

- **It removes the vocabulary barrier.** "Dimension", "measure" and "aggregation" are
  the three words that most reliably stop a non-technical user. The sentence never uses
  them; the underlying model is unchanged.
- **It is self-documenting.** A form shows what you *can* set. A sentence shows what you
  *have said*. People can read their own chart back and catch a mistake without
  understanding the query model.
- **It fits a narrow panel.** Shelf-based drag-and-drop needs width and a mouse.
- **Direct manipulation** (Shneiderman): the object of interest is on screen, every part
  of it is clickable, and the result is visible immediately with no Apply button.

Optional clauses are absent until relevant, not present-and-empty. A first chart has two
editable words; "+ split it" only appears once there is something to split.

### Suggestions instead of a blank canvas

A blank canvas with an "Add chart" button asks the least experienced user to make the
most open-ended decision. Instead: pick something to look at, get a shelf of live
suggestions rendered against real data, take one or several, and edit from there.

`lib/recommend.js` ranks candidates from property *types* — the lineage is Mackinlay's
automatic presentation work, later popularised as Tableau's "Show Me" and as
Voyager / CompassQL from the UW Interactive Data Lab (the same group behind Vega-Lite).
The point isn't that the machine chooses correctly. It's that adjusting something
concrete is far easier than specifying from nothing, which is why document tools open
with templates.

### Guardrails that teach

Unavailable chart types are shown, disabled, with the reason:

> Donut — *12 slices is too many to read — try bars*

Hiding it teaches nothing. Allowing it and complaining afterwards is worse. Prevention
beats an error message; an explanation beats silent prevention. When the data shape
drifts away from the current chart, an offer appears — never a silent switch.

### Other deliberate choices

| Decision | Reason |
|---|---|
| Filter values come from the data, as a checklist | Typing an exact string match against an unseen column is how filter UIs fail non-technical users: they type "emea", get nothing, conclude the tool is broken |
| Renaming a segment edits a **label**, not the data | Tools that make you rename upstream push a technical task onto the person least able to do it |
| Colours keyed to the series' real name | A category that changes colour between two views destroys trust in the chart |
| Colourblind-safe palette is the **default** | Okabe–Ito, not an accessibility toggle buried in a menu — the majority of charts built here are readable without anyone knowing why |
| Undo covers everything, including deletion | An obvious exit beats a "are you sure?" modal (Nielsen: user control and freedom) |
| Titles auto-generate from the sentence | Nobody should have to name a chart before seeing it |
| Progressive disclosure in the inspector | Someone who never opens Appearance still gets a well-coloured chart |
| Last good data stays while refetching | Charts fade instead of flashing empty |
| Popovers render into `document.body` | The rail and inspector are scroll containers; an inline popover gets clipped by them. It also flips above the anchor near the bottom of the screen and caps its height to the viewport |
| One store interface for both modes | localStorage and Foundry Actions implement the same seven methods, so there is no second persistence branch to drift out of sync |
| Save state is visible in the top bar | "Saving…" then "Live · v3", and "Not saved" in red if a write fails — a network write can fail in a way localStorage never did |

---

## Configuration-driven: how it actually works

Everything the builder can do derives from a property's **type**, never its name.

```
src/config/propertyTypes.js   ← the core config
```

| Registry | Drives |
|---|---|
| `TYPE_ALIASES` | Foundry types (`string`, `double`, `timestamp`, `geopoint`, `mediaReference`…) → kinds |
| `KINDS` | What each kind can do: group, measure, which aggregations, which operators |
| `AGGREGATIONS` | Plain-English labels + the OSDK `$select` suffix |
| `GROUPINGS` | `exact`, `topValues`, `fixedWidth`, `duration` → each builds its own `$groupBy` value |
| `OPERATORS` | Each builds its own OSDK `where` fragment |

Adding a Foundry property type is **one entry** in `KINDS`. Pickers, filters, chart
availability and the query compiler all read from the table — none of them need changing.
Unsupported types (attachments, media, vectors) are excluded gracefully rather than
crashing or appearing as broken options.

### The provider seam

Every screen talks to the ontology through five methods:

```js
listObjectTypes()                    → [{ apiName, displayName, description }]
describeObjectType(apiName)          → { properties[], links[], primaryKey }
distinctValues(objectType, prop, n)  → [{ value, count }]     // filter checklists
numericRange(objectType, prop)       → { min, max }           // range filters
aggregate(query)                     → { keys[], series[] }
```

`data/mockProvider.js` implements them against any schema handed to it.
`data/osdkProvider.js` implements them against real Foundry.

**Switching is one line in `main.jsx`.** No component knows which is in use.

```js
import { createOsdkProvider } from "./data/osdkProvider.js";
import { createClient } from "@osdk/client";
import { createPublicOauthClient } from "@osdk/oauth";
import * as Ontology from "@your-org/generated-sdk";

const auth = createPublicOauthClient(CLIENT_ID, FOUNDRY_URL, REDIRECT_URL);
const client = createClient(FOUNDRY_URL, ONTOLOGY_RID, auth);
const provider = createOsdkProvider(client, Ontology);
```

The OSDK provider uses `client.fetchMetadata(objectType)` for display names,
descriptions, property types and links. Palantir documents this specifically for
building interfaces that survive ontology changes without a code change — which is
exactly the requirement here.

**Authenticate as the end user, not a service account.** If your backend proxies queries
with a service token, Foundry's row-level security stops applying and every user sees
every row.

### What gets sent to OSDK

One `aggregate` call per widget. Multiple measures become multiple `$select` keys; a
split becomes a second `$groupBy` key; filters compose into one `where`:

```ts
client(Order)
  .where({ $and: [ { $or: [{ region: { $eq: "EMEA" } }] },
                    { orderDate: { $gte: "2026-06-07T…" } } ] })
  .aggregate({
    $select: { "revenue:sum": "unordered" },
    $groupBy: { region: "exact",
                channel: "topValues" }
  });
```

The inspector's "Under the hood" section shows this live for the selected chart — useful
when a technical reviewer asks what the tool is actually doing.

---

## `npm run check`

660 assertions, run against **two** ontologies: the sales demo, and a hospital
cold-chain logistics schema (`VaccineShipment`, `ClinicSite`) that shares no property,
type combination or domain concept with it and that `src/` has never seen.

For every object type in both, it verifies that suggestions generate, widgets normalize,
titles auto-write, queries compile, data returns, OSDK snippets emit, every legal chart
type compiles to valid Vega, every property produces working filter operators and real
values, and that renames and colour overrides reach the compiled spec.

It then greps every file in `src/` (comments stripped) for ontology-specific identifiers
— `revenue`, `region`, `Order`, `Customer` — and fails if any appear. That guard is what
stops the configuration-driven property eroding over time.

---

## Layout

```
src/
  config/
    propertyTypes.js    Type → capability registry. The core config.
    charts.js           Chart registry; availability rules return a REASON
    palettes.js         Colourblind-safe default
    demo-ontology.json  Demo data only — delete when you switch providers
  data/
    provider.js         The five-method contract
    bootstrap.js        Picks mock or Foundry from VITE_DATA_SOURCE
    mockProvider.js     Schema-agnostic mock
    osdkProvider.js     Real OSDK against your ontology
    client.js           Foundry client, browser OAuth as the signed-in user
    localStore.js       Persistence: localStorage
    dashboardStore.js   Persistence: DynamicLpDashboard + your 3 Actions
    foundry-missing.js  Stub used when the private SDK is not installed
  lib/
    spec.js             Widget model + normalize()
    compile.js          widget → neutral query → OSDK snippet
    recommend.js        Show Me / Voyager-style suggestions
    vegaSpec.js         query result → Vega-Lite, with styling
  components/
    SentenceBuilder.jsx The headline interaction
    FilterEditor.jsx    Type-driven filters with real value pickers
    StylePanel.jsx      Palettes, per-segment colour + rename
    StartScreen.jsx     Suggestion-driven empty state
    Inspector.jsx       Progressive disclosure
```

## Open-source worth adding next

Kept deliberately thin (React + Vega-Lite only) so the ideas are legible. If you take
this further:

- **dnd-kit** — accessible drag and drop, keyboard-operable. The current reorder is
  mouse-only, which is an accessibility gap.
- **Radix UI** or **react-aria** — the popovers here are hand-rolled; both give proper
  focus trapping, and correct ARIA that screen readers actually announce.
- **cmdk** — a ⌘K palette ("add a chart about…") suits the sentence model well.
- **TanStack Query** — replaces the small cache in `useWidgetData`; adds retries,
  background refresh, devtools.
- **Zod** — validate the saved spec on load and migrate old `schemaVersion` values.
- **Draco** — formal constraint-based visualization recommendation, if you want the
  suggestions to be principled rather than heuristic.

## Not built

- **Link traversal** (`Order → customer.country`). The provider already surfaces `links`
  from ontology metadata; the spec needs a `path` field. Design it in early — retrofitting
  means migrating every saved spec.
- **Cross-object-type charts.** OSDK can't do this in one call, and users will happily
  build charts that look fine and mean nothing. Link traversal covers most real cases.
## How dashboards are stored in Foundry

Your `DynamicLpDashboard` object type has four properties — `primaryKey_`,
`dashboardName`, `dashboardConfig`, `user` — and none can hold history. So
`dashboardConfig` holds an envelope:

```json
{
  "envelope": 1,
  "draft":     { "...": "spec" },
  "published": { "...": "spec" },
  "publishedVersion": 3,
  "versions": [ { "version": 3, "at": "...", "by": "...", "spec": {} } ]
}
```

Draft-vs-published keeps working with no ontology change: editing writes `draft`,
Share writes `published`, viewers read `published`. History caps at 10 entries
(`VERSION_LIMIT` in `dashboardStore.js`) so the string does not grow without
bound — move it to its own object type if you want more. A config written by
anything other than this app is read as a bare spec rather than discarded.

`dashboardStore.subscribe()` uses OSDK object-set subscriptions (needs
`@osdk/client` 2.1.x+; you are on 2.56), so a second editor shows up instead of
silently overwriting.

Authenticate as the **end user**. `createPublicOauthClient` runs the flow in the
browser, so every aggregation carries that user's permissions. Moving this
behind a backend service token would stop Foundry's row-level security applying
and show every user every row.
- **Real grid layout.** Reordering is drag-to-swap; swap in `react-grid-layout`.
