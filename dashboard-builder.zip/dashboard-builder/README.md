# Dashboard builder

A React + Vite prototype of a dashboard builder for non-technical users, backed by a
Palantir Ontology / OSDK query layer.

The whole product is a **JSON spec**. The builder writes it, the renderer reads it, and
the spec holds no SQL — only ontology references that compile into a single OSDK
aggregate call per chart.

## Run

```bash
npm install
npm run dev
```

## What works

- Pick one or more object types (left rail)
- Compose charts from three controls: source, group by, measure
- Multiple measures on one chart (bar + line, shared or independent axis)
- Split by a second dimension (stacked or side by side)
- Drag to reorder, resize to ¼ / ½ / full width
- Draft autosave, publish to an immutable version, restore an old version
- Undo/redo (Cmd/Ctrl+Z, Cmd/Ctrl+Shift+Z)
- "View spec" shows the live JSON; the inspector shows the compiled OSDK call

## Layout

```
src/
  ontology/ontology.js      Object types, properties, legal grouping strategies
  lib/spec.js               Spec shape, defaults, normalize()
  lib/query.js              MOCK data — replace with OSDK
  lib/osdk.js               spec → aggregate args + snippet
  lib/api.js                Persistence seam (localStorage → your API)
  store/useDashboard.js     State, undo/redo, autosave, versions
  components/               TopBar, SourceRail, Canvas, WidgetTile, Inspector, Drawer
  components/charts/        Chart registry: bar/line, donut, table, kpi
```

## Wiring it up for real

**1. Ontology metadata.** Replace `src/ontology/ontology.js` with metadata from your
generated SDK. Every picker derives its options from this, so correct metadata means
the UI can only build valid queries.

**2. Queries.** Replace `queryData` in `src/lib/query.js` with a real call, keeping the
return shape `{ keys, stacked, series: [{ name, chart, axis, values }] }`.
`aggregateArgs()` in `lib/osdk.js` already produces the arguments.

Initialise the OSDK client with the **end user's token**, not a service token. If your
API proxies queries with a service account, Foundry's row-level permissions stop
protecting anything and every user sees every row.

**3. Persistence.** Point the four functions in `src/lib/api.js` at your Express +
Postgres service:

```sql
create table dashboards (
  id uuid primary key,
  slug text unique not null,
  title text not null,
  draft_spec jsonb not null,
  published_version int,
  owner_id text not null,
  updated_at timestamptz default now()
);

create table dashboard_versions (
  dashboard_id uuid references dashboards(id) on delete cascade,
  version int not null,
  spec jsonb not null,
  label text,
  created_by text not null,
  created_at timestamptz default now(),
  primary key (dashboard_id, version)
);
```

Keep dashboard metadata in Postgres, not ClickHouse or a Foundry object — specs are
edited in small increments constantly, which is what those two handle worst.

## Design decisions worth keeping

**`normalize()` in `lib/spec.js`.** Users edit freely, so widgets reach states no
individual handler anticipated (a measure pointing at a property the new object type
lacks). Rather than defend in every handler, the renderer accepts any spec and repairs
it. This exists because the earlier prototype crashed on exactly that.

**Availability over validation.** Incompatible chart types are disabled, not hidden and
not rejected after the fact. A donut turns off above six groups.

**Split-by and multi-measure are mutually exclusive.** Two measures each split three ways
is six stacks per bar. Loosen it in `normalize()` if you disagree.

**Draft vs published.** Autosave writes the draft; Publish snapshots a version. Without
the split, every drag becomes a version and history is useless.

## Not built

- **Link traversal** (`Order → customer.country`). The `path` field is reserved in the
  spec. Design it in early — retrofitting means migrating every saved spec.
- **Filter picker.** The filter bar is static.
- **Cross-object-type charts.** OSDK can't do this in one call; it needs two queries and
  a client-side join, and users will happily build charts that look fine and mean
  nothing. Prefer link traversal.
- **Real grid layout.** Reordering is drag-to-swap. Swap in `react-grid-layout` and have
  it emit a `layout[]` array into the spec.
