import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { createRequire } from "module";
import path from "path";

const require = createRequire(import.meta.url);

/**
 * The Foundry packages live in a private registry, so a checkout without access
 * must still build and run in mock mode. This aliases any that are absent to a
 * stub that throws only if something actually calls them — the app never does
 * unless VITE_DATA_SOURCE=foundry.
 *
 * Install the real ones and the alias disappears; no code changes.
 */
function optionalFoundry() {
  const pkgs = [
    "@fdc9-skywiseperfodynamiclp/sdk",
    "@osdk/client",
    "@osdk/oauth",
    "@osdk/foundry.admin"
  ];
  const missing = pkgs.filter((p) => {
    try { require.resolve(p); return false; } catch { return true; }
  });

  return {
    name: "optional-foundry",
    config() {
      if (!missing.length) return {};
      const stub = path.resolve(process.cwd(), "src/data/foundry-missing.js");
      return {
        resolve: { alias: Object.fromEntries(missing.map((p) => [p, stub])) }
      };
    },
    configResolved() {
      if (missing.length) {
        console.log(`\n  Foundry SDK not installed — running in mock mode.`);
        console.log(`  Missing: ${missing.join(", ")}\n`);
      }
    }
  };
}

export default defineConfig({
  plugins: [react(), optionalFoundry()],
  server: { port: 5173 }
});
