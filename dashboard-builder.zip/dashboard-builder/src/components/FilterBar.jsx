export default function FilterBar({ onAdd }) {
  const filters = [
    { label: "Order date", value: "Last 90 days" },
    { label: "Region", value: "All" },
    { label: "Status", value: "Shipped" }
  ];
  return (
    <div className="filterbar">
      {filters.map((f) => (
        <div className="filter" key={f.label}>
          <span>{f.label}</span>
          <b>{f.value}</b>
        </div>
      ))}
      <button className="btn" onClick={onAdd}>
        Add filter
      </button>
    </div>
  );
}
