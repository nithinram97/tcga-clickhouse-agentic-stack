import { ONTOLOGY } from "../ontology/ontology.js";
import { objectTypeOf, subtitleOf } from "../lib/spec.js";
import { queryData } from "../lib/query.js";
import ChartRenderer from "./charts/ChartRenderer.jsx";

export default function WidgetTile({ spec, widget, selected, onSelect, onDragStart, onDragOver }) {
  const data = queryData(spec, widget);
  return (
    <div
      className={`tile w${widget.span}${selected ? " sel" : ""}`}
      onClick={() => onSelect(widget.id)}
      draggable
      onDragStart={() => onDragStart(widget.id)}
      onDragOver={(e) => {
        e.preventDefault();
        onDragOver(widget.id);
      }}
    >
      <span className="grip" aria-hidden="true">⠿</span>
      <div className="tile-head">
        <span className="tile-title">{widget.title}</span>
        <span className="tile-src">{ONTOLOGY[objectTypeOf(spec, widget)].label}</span>
      </div>
      <div className="tile-sub">{subtitleOf(spec, widget)}</div>
      <ChartRenderer spec={spec} widget={widget} data={data} />
    </div>
  );
}
