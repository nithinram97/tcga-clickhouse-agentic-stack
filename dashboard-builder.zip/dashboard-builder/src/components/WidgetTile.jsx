import { useMemo } from "react";
import { titleOf, propOf } from "../lib/spec.js";
import { useWidgetData } from "../store/useWidgetData.js";
import ChartRenderer from "./charts/ChartRenderer.jsx";

export default function WidgetTile({
  meta, widget, selected, crossFilter, onCrossFilter,
  onSelect, onDragStart, onDragOver
}) {
  const extra = useMemo(
    () => (crossFilter && crossFilter.widgetId !== widget.id && crossFilter.objectType === widget.objectType
      ? [{ property: crossFilter.property, operator: "eq", value: crossFilter.value }]
      : []),
    [crossFilter, widget.id, widget.objectType]
  );

  const { data, loading } = useWidgetData(meta, widget, extra);
  const canSelect = widget.groupBy && ["bar", "column"].includes(widget.chart);

  return (
    <div
      className={`tile w${widget.span}${selected ? " sel" : ""}${loading && !data ? " loading" : ""}`}
      onClick={() => onSelect(widget.id)}
      draggable
      onDragStart={() => onDragStart(widget.id)}
      onDragOver={(e) => { e.preventDefault(); onDragOver(widget.id); }}
    >
      <span className="grip" aria-hidden="true">⠿</span>
      <div className="tile-head">
        <span className="tile-title">{meta ? titleOf(meta, widget) : "…"}</span>
        <span className="tile-src">{meta?.displayName}</span>
      </div>
      {widget.filters?.length > 0 && (
        <div className="tile-filters">
          {widget.filters.length} filter{widget.filters.length > 1 ? "s" : ""}
        </div>
      )}

      {data ? (
        <ChartRenderer
          widget={widget}
          data={data}
          height={widget.chart === "kpi" ? 60 : 132}
          onSelect={
            canSelect
              ? (value) =>
                  onCrossFilter(
                    value
                      ? {
                          widgetId: widget.id,
                          objectType: widget.objectType,
                          property: widget.groupBy.property,
                          label: propOf(meta, widget.groupBy.property)?.displayName,
                          value
                        }
                      : null
                  )
              : undefined
          }
        />
      ) : (
        <div className="chart-loading" />
      )}
    </div>
  );
}
