import { CHARTS, CHART_ORDER } from "../config/charts.js";
import { shapeOf } from "../lib/spec.js";

/**
 * Chart types, with reasons.
 *
 * An unavailable type is shown, disabled, with the reason it does not fit —
 * "12 slices is too many to read — try bars". Hiding it would teach nothing;
 * allowing it and then complaining would be worse. Prevention beats an error
 * message, and an explanation beats silent prevention.
 */
export default function ChartTypePicker({ meta, widget, data, onPick }) {
  const shape = shapeOf(meta, widget, data);

  return (
    <div className="ctypes">
      {CHART_ORDER.map((id) => {
        const c = CHARTS[id];
        const fit = c.fits(shape);
        const ok = fit === true;
        return (
          <button
            key={id}
            className={`ctype${widget.chart === id ? " on" : ""}`}
            disabled={!ok}
            title={ok ? c.hint : fit}
            onClick={() => onPick(id)}
          >
            <span className="ctype-icon">{c.icon}</span>
            <span className="ctype-label">{c.label}</span>
            {!ok && <span className="ctype-why">{fit}</span>}
          </button>
        );
      })}
    </div>
  );
}
