import { FILLS } from "./palette.js";

const R = 15.9155;
const C = 2 * Math.PI * R;

export default function DonutChart({ data }) {
  const vals =
    data.series.length > 1
      ? data.series.map((s) => ({
          key: s.name,
          value: s.values.reduce((a, b) => a + b, 0)
        }))
      : data.keys.map((k, i) => ({ key: k, value: data.series[0].values[i] }));

  const total = vals.reduce((a, r) => a + r.value, 0) || 1;
  let acc = 0;

  return (
    <div className="donut-wrap">
      <svg viewBox="0 0 42 42" width="106" height="106" role="img" aria-label="Donut chart">
        {vals.map((r, i) => {
          const dash = (r.value / total) * C;
          const el = (
            <circle
              key={r.key}
              cx="21"
              cy="21"
              r={R}
              fill="none"
              stroke={FILLS[i % FILLS.length]}
              strokeWidth="7"
              strokeDasharray={`${dash.toFixed(2)} ${(C - dash).toFixed(2)}`}
              strokeDashoffset={-acc}
              transform="rotate(-90 21 21)"
            />
          );
          acc += dash;
          return el;
        })}
      </svg>
      <div className="donut-legend">
        {vals.map((r, i) => (
          <div key={r.key}>
            <span className="swatch" style={{ background: FILLS[i % FILLS.length] }} />
            <span className="donut-key">{r.key}</span>
            <span className="mono donut-pct">{Math.round((r.value / total) * 100)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}
