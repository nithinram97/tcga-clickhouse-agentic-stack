export default function AxisLabels({ keys }) {
  return (
    <div className="axis-labels">
      {keys.map((k, i) => (
        <span key={k + i}>{k}</span>
      ))}
    </div>
  );
}
