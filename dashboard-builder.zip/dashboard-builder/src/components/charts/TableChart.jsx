import { fmtNumber } from "../../lib/format.js";
import { displayName } from "../../lib/vegaSpec.js";

export default function TableChart({ widget, data }) {
  const style = widget.style ?? {};
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            <th />
            {data.series.map((s) => (
              <th key={s.name}>{displayName(style, s.name)}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.keys.map((k, i) => (
            <tr key={k}>
              <td>{k}</td>
              {data.series.map((s) => (
                <td key={s.name} className="mono num">
                  {fmtNumber(s.values[i], { style: style.format === "full" ? "full" : style.format })}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
