import { useCallback, useEffect, useMemo, useRef } from "react";
import { VegaEmbed } from "react-vega";
import { buildSpec, SELECT } from "../../lib/vegaSpec.js";

const OPTIONS = { actions: false, renderer: "svg" };

export default function VegaChart({ widget, data, onSelect, height }) {
  const spec = useMemo(
    () => buildSpec(widget, data, { selectable: !!onSelect, height }),
    [widget, data, onSelect, height]
  );

  const cb = useRef(onSelect);
  useEffect(() => { cb.current = onSelect; }, [onSelect]);

  const onEmbed = useCallback((result) => {
    const view = result?.view;
    if (!view) return;
    try {
      view.addSignalListener(`${SELECT}_tuple`, (_n, tuple) => {
        cb.current?.(tuple?.values?.[0] ?? null);
      });
    } catch {
      // Charts without a selection param (donut, line-only) have no such signal.
    }
  }, []);

  return (
    <div className="vega-host">
      <VegaEmbed spec={spec} options={OPTIONS} onEmbed={onEmbed} onError={(e) => console.error(e)} />
    </div>
  );
}
