import { FILLS } from "./palette.js";
import AxisLabels from "./AxisLabels.jsx";
import Legend from "./Legend.jsx";

const W = 100;
const H = 46;

/**
 * Handles bars, lines, and any mix of the two, stacked or side by side, on one
 * or two scales. Series with axis "right" are scaled independently.
 */
export default function BarLineChart({ data }) {
  const bars = data.series.filter((s) => s.chart === "bar");
  const lines = data.series.filter((s) => s.chart === "line");
  const n = data.keys.length;

  const leftVals = [];
  const rightVals = [];
  data.series.forEach((s) => (s.axis === "right" ? rightVals : leftVals).push(...s.values));
  if (data.stacked) {
    leftVals.length = 0;
    data.keys.forEach((k, i) => leftVals.push(bars.reduce((a, s) => a + s.values[i], 0)));
  }
  const lMax = Math.max(...leftVals, 1);
  const rMax = Math.max(...rightVals, 1);
  const maxFor = (s) => (s.axis === "right" ? rMax : lMax);

  const gap = 2.5;
  const slot = (W - gap * (n - 1)) / n;
  const idxOf = (s) => data.series.indexOf(s);
  const rects = [];

  if (bars.length) {
    if (data.stacked) {
      data.keys.forEach((k, i) => {
        let y = H;
        bars.forEach((s) => {
          const h = Math.max(0.8, (s.values[i] / lMax) * H);
          y -= h;
          rects.push(
            <rect
              key={`${s.name}-${i}`}
              x={i * (slot + gap)}
              y={y}
              width={slot}
              height={h}
              fill={FILLS[idxOf(s) % FILLS.length]}
            />
          );
        });
      });
    } else {
      const bw = slot / bars.length;
      bars.forEach((s, si) =>
        s.values.forEach((v, i) => {
          const h = Math.max(1.2, (v / maxFor(s)) * H);
          rects.push(
            <rect
              key={`${s.name}-${i}`}
              x={i * (slot + gap) + si * bw}
              y={H - h}
              width={bw - (bars.length > 1 ? 0.6 : 0)}
              height={h}
              rx="0.8"
              fill={FILLS[idxOf(s) % FILLS.length]}
              opacity={bars.length > 1 ? 1 : 1 - i * 0.1}
            />
          );
        })
      );
    }
  }

  const paths = lines.map((s) => {
    const pts = s.values.map((v, i) => [
      n === 1 ? W / 2 : i * (slot + gap) + slot / 2,
      H - (v / maxFor(s)) * H * 0.9
    ]);
    const d = pts.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(2)} ${p[1].toFixed(2)}`).join(" ");
    const c = FILLS[idxOf(s) % FILLS.length];
    return (
      <g key={s.name}>
        {!bars.length && (
          <path d={`${d} L ${W} ${H} L 0 ${H} Z`} fill={c} opacity="0.14" />
        )}
        <path
          d={d}
          fill="none"
          stroke={c}
          strokeWidth="1.4"
          strokeLinejoin="round"
          vectorEffect="non-scaling-stroke"
        />
        {pts.map((p, i) => (
          <circle key={i} cx={p[0]} cy={p[1]} r="1.1" fill={c} vectorEffect="non-scaling-stroke" />
        ))}
      </g>
    );
  });

  return (
    <>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        width="100%"
        height="122"
        preserveAspectRatio="none"
        role="img"
        aria-label="Chart"
      >
        {rects}
        {paths}
      </svg>
      <AxisLabels keys={data.keys} />
      <Legend series={data.series} />
    </>
  );
}
