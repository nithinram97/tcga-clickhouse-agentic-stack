import { Suspense, lazy } from "react";
import { VEGA_CHARTS } from "../../config/charts.js";
import TableChart from "./TableChart.jsx";
import KpiChart from "./KpiChart.jsx";

// Vega is ~300 kB gzipped, so it loads on demand. A dashboard of only KPIs and
// tables never downloads it.
const VegaChart = lazy(() => import("./VegaChart.jsx"));

export default function ChartRenderer({ widget, data, onSelect, height = 132 }) {
  if (!data?.series?.length) return <div className="chart-loading" />;

  if (VEGA_CHARTS.has(widget.chart)) {
    return (
      <Suspense fallback={<div className="chart-loading" />}>
        <VegaChart widget={widget} data={data} onSelect={onSelect} height={height} />
      </Suspense>
    );
  }
  const C = widget.chart === "table" ? TableChart : KpiChart;
  return <C widget={widget} data={data} />;
}
