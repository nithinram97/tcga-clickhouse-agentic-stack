import BarLineChart from "./BarLineChart.jsx";
import DonutChart from "./DonutChart.jsx";
import TableChart from "./TableChart.jsx";
import KpiChart from "./KpiChart.jsx";

/**
 * Registry. Adding a chart type is one file plus one entry here — and one
 * availability rule in Inspector so users are only offered it where it makes
 * sense.
 */
const CHARTS = {
  bar: BarLineChart,
  line: BarLineChart,
  donut: DonutChart,
  table: TableChart,
  kpi: KpiChart
};

export default function ChartRenderer({ spec, widget, data }) {
  const Chart = CHARTS[widget.series[0].chart] || BarLineChart;
  return <Chart spec={spec} widget={widget} data={data} />;
}
