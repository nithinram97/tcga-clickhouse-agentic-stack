import { fmtNumber } from "../../lib/format.js";
import { displayName } from "../../lib/vegaSpec.js";

export default function KpiChart({ widget, data }) {
  const style = widget.style ?? {};
  return (
    <div className={data.series.length > 1 ? "kpis multi" : "kpis"}>
      {data.series.map((s) => (
        <div className="kpi" key={s.name}>
          <div className="kpi-val mono">
            {fmtNumber(s.values[0], { style: style.format === "full" ? "full" : style.format })}
          </div>
          {data.series.length > 1 && <div className="kpi-label">{displayName(style, s.name)}</div>}
        </div>
      ))}
    </div>
  );
}
