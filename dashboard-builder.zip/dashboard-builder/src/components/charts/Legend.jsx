import { FILLS } from "./palette.js";

export default function Legend({ series }) {
  if (series.length < 2) return null;
  return (
    <div className="legend">
      {series.map((s, i) => (
        <span key={s.name + i}>
          <i className="swatch" style={{ background: FILLS[i % FILLS.length] }} />
          {s.name}
          {s.axis === "right" && <i className="axis-tag">right</i>}
        </span>
      ))}
    </div>
  );
}
