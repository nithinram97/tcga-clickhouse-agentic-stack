import { useState } from "react";
import { betterChartFor } from "../lib/recommend.js";
import { shapeOf, titleOf, propOf } from "../lib/spec.js";
import { osdkSnippet } from "../lib/compile.js";
import { CHARTS } from "../config/charts.js";
import { useWidgetData } from "../store/useWidgetData.js";
import SentenceBuilder from "./SentenceBuilder.jsx";
import ChartTypePicker from "./ChartTypePicker.jsx";
import FilterEditor from "./FilterEditor.jsx";
import StylePanel from "./StylePanel.jsx";

/**
 * The inspector.
 *
 * Progressive disclosure, in a deliberate order: the sentence is always visible
 * because it is the chart; everything else is collapsed. A first-time user sees
 * one thing to edit, and the sections below reveal themselves only when sought.
 * Someone who never opens Appearance still gets a well-coloured chart.
 */
export default function Inspector({ meta, widget, onChange, onDuplicate, onRemove }) {
  // Split so the hooks below are never called conditionally.
  if (!widget || !meta) {
    return (
      <aside className="inspector">
        <div className="insp-head"><span className="insp-title">Nothing selected</span></div>
        <div className="empty">Pick a chart to edit it, or add a new one from the canvas.</div>
      </aside>
    );
  }
  return (
    <InspectorBody
      key={widget.id}
      meta={meta}
      widget={widget}
      onChange={onChange}
      onDuplicate={onDuplicate}
      onRemove={onRemove}
    />
  );
}

function InspectorBody({ meta, widget, onChange, onDuplicate, onRemove }) {
  const [openSection, setOpenSection] = useState(null);
  const { data, query } = useWidgetData(meta, widget, []);
  const shape = shapeOf(meta, widget, data);
  const better = data ? betterChartFor(shape, widget.chart) : null;
  const seriesNames = data?.series?.map((s) => s.name) ?? [];

  const Section = ({ id, label, summary, children }) => {
    const open = openSection === id;
    return (
      <div className={`sect${open ? " open" : ""}`}>
        <button className="sect-head" onClick={() => setOpenSection(open ? null : id)}>
          <span className="sect-name">{label}</span>
          <span className="sect-sum">{summary}</span>
          <span className="sect-caret">{open ? "▴" : "▾"}</span>
        </button>
        {open && <div className="sect-body">{children}</div>}
      </div>
    );
  };

  return (
    <aside className="inspector">
      <div className="insp-head">
        <span className="insp-title">Chart</span>
        <span className="insp-actions">
          <button className="btn icon" title="Duplicate" onClick={() => onDuplicate(widget.id)}>⧉</button>
          <button className="btn icon danger" title="Remove" onClick={() => onRemove(widget.id)}>🗑</button>
        </span>
      </div>

      <div className="insp-body">
        <SentenceBuilder meta={meta} widget={widget} onChange={(fn) => onChange(widget.id, fn)} />

        {better && (
          <button
            className="nudge"
            onClick={() => onChange(widget.id, (w) => { w.chart = better; })}
          >
            <b>{CHARTS[better].label}</b> would suit this better — switch?
          </button>
        )}

        <div className="sect-label mt">Show it as</div>
        <ChartTypePicker
          meta={meta}
          widget={widget}
          data={data}
          onPick={(c) => onChange(widget.id, (w) => { w.chart = c; })}
        />

        <Section
          id="filters"
          label="Filters"
          summary={widget.filters?.length ? `${widget.filters.length} applied` : "All data"}
        >
          <FilterEditor
            meta={meta}
            filters={widget.filters ?? []}
            onChange={(fn) => onChange(widget.id, (w) => fn(w.filters))}
          />
        </Section>

        <Section
          id="style"
          label="Appearance"
          summary={Object.keys(widget.style?.labels ?? {}).length ? "Customised" : "Default colours"}
        >
          <StylePanel
            widget={widget}
            seriesNames={seriesNames}
            onChange={(fn) => onChange(widget.id, fn)}
          />
        </Section>

        <Section id="layout" label="Size and title" summary={widget.title ? "Custom title" : "Auto"}>
          <label className="fieldlabel">Title</label>
          <input
            className="ctl"
            value={widget.title ?? ""}
            placeholder={titleOf(meta, widget)}
            onChange={(e) => onChange(widget.id, (w) => { w.title = e.target.value; })}
          />
          <div className="sect-label mt">Width</div>
          <div className="seg">
            {[{ s: 1, l: "¼" }, { s: 2, l: "½" }, { s: 3, l: "¾" }, { s: 4, l: "Full" }].map((o) => (
              <button
                key={o.s}
                className={widget.span === o.s ? "on" : ""}
                onClick={() => onChange(widget.id, (w) => { w.span = o.s; })}
              >
                {o.l}
              </button>
            ))}
          </div>
          {widget.groupBy && (
            <>
              <div className="sect-label mt">Show at most</div>
              <div className="seg">
                {[6, 12, 20, 50].map((n) => (
                  <button
                    key={n}
                    className={widget.limit === n ? "on" : ""}
                    onClick={() => onChange(widget.id, (w) => { w.limit = n; })}
                  >
                    {n}
                  </button>
                ))}
              </div>
            </>
          )}
        </Section>

        <Section id="query" label="Under the hood" summary="OSDK query">
          <p className="hint-note">
            This is the query your chart runs. One aggregate call, built from the ontology.
          </p>
          <pre className="code">{query ? osdkSnippet(meta, query) : ""}</pre>
        </Section>
      </div>
    </aside>
  );
}
