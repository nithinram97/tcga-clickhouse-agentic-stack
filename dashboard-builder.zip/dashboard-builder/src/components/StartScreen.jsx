import { useMemo, useState } from "react";
import { suggestWidgets } from "../lib/recommend.js";
import { autoTitle } from "../lib/spec.js";
import { useWidgetData } from "../store/useWidgetData.js";
import ChartRenderer from "./charts/ChartRenderer.jsx";

/**
 * The empty state.
 *
 * A blank canvas with an "Add chart" button is the hardest screen in any
 * builder: it asks the least experienced user to make the most open-ended
 * decision. Instead, pick a thing to look at and get a shelf of live, real-data
 * suggestions. Take one and edit it, or take several at once.
 *
 * Starting from something concrete and adjusting it is far easier than
 * specifying from nothing — the same reason document tools open with templates.
 */
export default function StartScreen({ objectTypes, metaFor, onAdd, onAddMany }) {
  const [picked, setPicked] = useState(null);
  const meta = picked ? metaFor(picked) : null;
  const suggestions = useMemo(() => (meta ? suggestWidgets(meta) : []), [meta]);
  const [chosen, setChosen] = useState(() => new Set());

  if (!picked) {
    return (
      <div className="start">
        <h1>What do you want to look at?</h1>
        <p className="start-sub">Pick anything to start. You can add more later.</p>
        <div className="ot-grid">
          {objectTypes.map((o) => {
            const m = metaFor(o.apiName);
            return (
              <button key={o.apiName} className="ot-card" onClick={() => setPicked(o.apiName)}>
                <span className="ot-name">{o.displayName}</span>
                {o.description && <span className="ot-desc">{o.description}</span>}
                <span className="ot-meta">{m ? `${m.properties.length} fields` : ""}</span>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  const toggle = (i) =>
    setChosen((prev) => {
      const n = new Set(prev);
      n.has(i) ? n.delete(i) : n.add(i);
      return n;
    });

  return (
    <div className="start wide">
      <div className="start-head">
        <div>
          <h1>Charts we can build from {meta.displayName.toLowerCase()}s</h1>
          <p className="start-sub">Tap any to add it. Everything stays editable.</p>
        </div>
        <button className="btn" onClick={() => { setPicked(null); setChosen(new Set()); }}>
          ← Change
        </button>
      </div>

      <div className="sugg-grid">
        {suggestions.map((s, i) => (
          <SuggestionCard
            key={s.id}
            meta={meta}
            widget={s}
            chosen={chosen.has(i)}
            onToggle={() => toggle(i)}
          />
        ))}
      </div>

      <div className="start-actions">
        <button
          className="btn primary"
          disabled={!chosen.size}
          onClick={() => onAddMany([...chosen].map((i) => suggestions[i]))}
        >
          Add {chosen.size || ""} chart{chosen.size === 1 ? "" : "s"}
        </button>
        <button className="btn" onClick={() => onAdd(suggestions[0])}>
          Start with a blank chart
        </button>
      </div>
    </div>
  );
}

function SuggestionCard({ meta, widget, chosen, onToggle }) {
  const { data } = useWidgetData(meta, widget, []);
  return (
    <button className={`sugg${chosen ? " on" : ""}`} onClick={onToggle}>
      <div className="sugg-head">
        <span className="sugg-title">{autoTitle(meta, widget)}</span>
        <span className="sugg-check">{chosen ? "✓" : "+"}</span>
      </div>
      <div className="sugg-why">{widget._why}</div>
      <div className="sugg-chart">
        {data ? <ChartRenderer widget={widget} data={data} height={94} /> : <div className="chart-loading" />}
      </div>
    </button>
  );
}
