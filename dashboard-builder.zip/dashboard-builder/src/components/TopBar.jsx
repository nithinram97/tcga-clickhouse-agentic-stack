export default function TopBar({
  spec, dirty, saving, saveError, publishedVersion, mode,
  onTitle, onUndo, onRedo, onSpec, onVersions, onPublish
}) {
  const status = saveError
    ? { className: "chip error", text: "Not saved" }
    : saving
    ? { className: "chip", text: "Saving…" }
    : dirty
    ? { className: "chip", text: "Draft" }
    : publishedVersion
    ? { className: "chip live", text: `Live · v${publishedVersion}` }
    : { className: "chip", text: "Draft" };

  return (
    <div className="topbar">
      <div className="brand">
        <div className="brand-mark" aria-hidden="true" />
        <div className="brand-name">Dashboards</div>
        {mode === "mock" && <span className="mode-tag" title="Using the built-in demo ontology">demo</span>}
      </div>
      <input
        className="doc-title-input"
        value={spec.title}
        onChange={(e) => onTitle(e.target.value)}
        aria-label="Dashboard title"
      />
      <div className="topbar-right">
        <span className={status.className} title={saveError ? String(saveError.message ?? saveError) : undefined}>
          {status.text}
        </span>
        <button className="btn icon" onClick={onUndo} title="Undo (Ctrl+Z)">↶</button>
        <button className="btn icon" onClick={onRedo} title="Redo (Ctrl+Shift+Z)">↷</button>
        <button className="btn" onClick={onSpec}>Spec</button>
        <button className="btn" onClick={onVersions}>History</button>
        <button className="btn primary" onClick={onPublish}>Share</button>
      </div>
    </div>
  );
}
