import { useState } from "react";
import { AGGREGATIONS, GROUPINGS, kindConfig, isTime } from "../config/propertyTypes.js";
import { defaultGrouping, defaultMeasure, groupableProps, measurableProps, propOf, plural, uid } from "../lib/spec.js";
import Popover from "./Popover.jsx";
import FieldPicker from "./FieldPicker.jsx";

/**
 * THE SENTENCE BUILDER — the core interaction of this app.
 *
 * Instead of a form of labelled inputs ("Dimension", "Measure", "Aggregation"),
 * the chart definition reads as an English sentence whose nouns are editable:
 *
 *     Show  total revenue  for every  region  split by  channel
 *
 * Why this and not a form or drag-and-drop shelves:
 *
 * 1. It removes the vocabulary barrier. "Dimension" and "measure" are the two
 *    words that most reliably stop a non-technical user; the sentence never
 *    uses them, but the underlying model is unchanged.
 * 2. It is self-documenting. A form shows what you can set; a sentence shows
 *    what you have said. Users can read their own chart back and catch mistakes
 *    without understanding the query model.
 * 3. It survives on small screens and in a narrow panel, where shelf-based
 *    drag-and-drop does not.
 * 4. Direct manipulation (Shneiderman): the object of interest is on screen and
 *    every part of it is clickable, with the result visible immediately.
 *
 * Optional parts are absent until relevant rather than present-and-empty, which
 * is progressive disclosure: the first-time sentence has three editable words.
 */
export default function SentenceBuilder({ meta, widget, onChange }) {
  const [open, setOpen] = useState(null);
  const close = () => setOpen(null);
  const set = (fn) => { onChange(fn); close(); };

  const measures = measurableProps(meta);
  const groups = groupableProps(meta);
  const m0 = widget.measures[0];
  const groupProp = widget.groupBy ? propOf(meta, widget.groupBy.property) : null;
  const splitProp = widget.split ? propOf(meta, widget.split.property) : null;

  const Chip = ({ id, children, tone = "" }) => (
    <span className="chip-wrap">
      <button className={`sc ${tone}${open === id ? " open" : ""}`} onClick={() => setOpen(open === id ? null : id)}>
        {children}
      </button>
      <Popover open={open === id} onClose={close} width={280}>
        {open === id && panelFor(id)}
      </Popover>
    </span>
  );

  const measurePanel = (m, idx) => (
    <>
      <div className="pop-head">What do you want to measure?</div>
      <div className="agg-row">
        {(m.property ? kindConfig(propOf(meta, m.property).type).aggregations : ["count"]).map((fn) => (
          <button
            key={fn}
            className={`agg${m.fn === fn ? " on" : ""}`}
            onClick={() => onChange((w) => { w.measures[idx].fn = fn; })}
          >
            {AGGREGATIONS[fn].label}
          </button>
        ))}
      </div>
      <FieldPicker
        properties={measures}
        value={m.property}
        onClear={() => set((w) => {
          w.measures[idx].property = null;
          w.measures[idx].fn = "count";
        })}
        clearLabel={`Just count ${plural(meta.displayName)}`}
        onPick={(p) => set((w) => {
          const cfg = kindConfig(p.type);
          w.measures[idx].property = p.apiName;
          if (!cfg.aggregations.includes(w.measures[idx].fn)) {
            w.measures[idx].fn = cfg.defaultAggregation ?? cfg.aggregations[0];
          }
        })}
      />
    </>
  );

  const panelFor = (id) => {
    if (id.startsWith("measure:")) {
      const idx = Number(id.split(":")[1]);
      return measurePanel(widget.measures[idx], idx);
    }
    if (id === "group") {
      return (
        <>
          <div className="pop-head">Break the numbers down by…</div>
          <FieldPicker
            properties={groups}
            value={widget.groupBy?.property}
            onClear={() => set((w) => { w.groupBy = null; w.split = null; })}
            clearLabel="Don't break down — one total"
            onPick={(p) => set((w) => {
              w.groupBy = defaultGrouping(p);
              if (w.split?.property === p.apiName) w.split = null;
              if (w.chart === "kpi") w.chart = isTime(p) ? "line" : "bar";
            })}
          />
        </>
      );
    }
    if (id === "grouping") {
      const cfg = kindConfig(groupProp.type);
      const g = GROUPINGS[widget.groupBy.strategy];
      return (
        <>
          <div className="pop-head">How should {groupProp.displayName.toLowerCase()} be grouped?</div>
          <div className="opt-list">
            {cfg.groupings.map((s) => (
              <button
                key={s}
                className={`opt${widget.groupBy.strategy === s ? " on" : ""}`}
                onClick={() => onChange((w) => {
                  w.groupBy.strategy = s;
                  w.groupBy.options = { ...(GROUPINGS[s].defaults ?? {}) };
                })}
              >
                {GROUPINGS[s].label}
              </button>
            ))}
          </div>
          {g.units && (
            <div className="unit-row">
              {g.units.map((u) => (
                <button
                  key={u}
                  className={`unit${widget.groupBy.options?.unit === u ? " on" : ""}`}
                  onClick={() => onChange((w) => { w.groupBy.options = { ...w.groupBy.options, unit: u }; })}
                >
                  {u}
                </button>
              ))}
            </div>
          )}
        </>
      );
    }
    if (id === "split") {
      return (
        <>
          <div className="pop-head">Split each bar by…</div>
          <p className="pop-note">
            Each {groupProp?.displayName.toLowerCase() ?? "group"} gets divided into segments.
          </p>
          <FieldPicker
            properties={groups.filter((p) => p.apiName !== widget.groupBy?.property && !isTime(p))}
            value={widget.split?.property}
            onClear={() => set((w) => { w.split = null; })}
            clearLabel="No split"
            onPick={(p) => set((w) => {
              w.split = { ...defaultGrouping(p), limit: 4 };
              if (w.measures.length > 1) w.measures = [w.measures[0]];
              if (w.chart === "donut") w.chart = "bar";
            })}
          />
        </>
      );
    }
    return null;
  };

  const canAddMeasure = widget.groupBy && !widget.split && widget.measures.length < 3 && measures.length > 1;

  return (
    <div className="sentence">
      <span className="sw">Show</span>

      {widget.measures.map((m, i) => (
        <span key={m.id}>
          {i > 0 && <span className="sw">and</span>}
          <Chip id={`measure:${i}`} tone="measure">
            {m.fn === "count" || !m.property
              ? `how many ${plural(meta.displayName)}`
              : `${AGGREGATIONS[m.fn].short} ${propOf(meta, m.property)?.displayName.toLowerCase()}`}
          </Chip>
          {i > 0 && (
            <button
              className="sx"
              title="Remove this measure"
              onClick={() => onChange((w) => { w.measures.splice(i, 1); })}
            >
              ×
            </button>
          )}
        </span>
      ))}

      {canAddMeasure && (
        <button
          className="sadd"
          onClick={() => onChange((w) => {
            const used = w.measures.map((x) => x.property);
            const next = measures.find((p) => !used.includes(p.apiName)) ?? measures[0];
            const m = defaultMeasure(next);
            w.measures.push({ ...m, id: uid("m"), chart: "line", axis: "right" });
          })}
        >
          + and another
        </button>
      )}

      <span className="sw">{widget.groupBy ? "for every" : "in total"}</span>

      {widget.groupBy ? (
        <>
          <Chip id="group" tone="group">{groupProp?.displayName.toLowerCase()}</Chip>
          {kindConfig(groupProp.type).groupings.length > 1 || GROUPINGS[widget.groupBy.strategy].units ? (
            <Chip id="grouping" tone="quiet">
              {GROUPINGS[widget.groupBy.strategy].units
                ? `by ${widget.groupBy.options?.unit ?? "months"}`
                : GROUPINGS[widget.groupBy.strategy].label}
            </Chip>
          ) : null}
        </>
      ) : (
        <Chip id="group" tone="ghost">+ break it down</Chip>
      )}

      {widget.groupBy && widget.measures.length === 1 && (
        <>
          <span className="sw">{widget.split ? "split by" : ""}</span>
          {widget.split ? (
            <>
              <Chip id="split" tone="group">{splitProp?.displayName.toLowerCase()}</Chip>
              <button className="sx" title="Remove split" onClick={() => onChange((w) => { w.split = null; })}>×</button>
            </>
          ) : (
            <Chip id="split" tone="ghost">+ split it</Chip>
          )}
        </>
      )}
    </div>
  );
}
