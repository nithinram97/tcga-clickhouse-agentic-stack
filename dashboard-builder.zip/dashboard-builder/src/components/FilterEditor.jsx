import { useEffect, useState } from "react";
import { OPERATORS, RELATIVE_PRESETS, kindConfig } from "../config/propertyTypes.js";
import { filterableProps, propOf, uid } from "../lib/spec.js";
import { useProvider } from "../data/provider.js";
import Popover from "./Popover.jsx";
import FieldPicker from "./FieldPicker.jsx";

/**
 * Filters, driven entirely by property type.
 *
 * The operator list, the input control and the OSDK clause all come from
 * config/propertyTypes.js. Adding a new property type gives you working filters
 * for free.
 *
 * Value pickers are populated from the DATA, not typed by hand. Asking someone
 * to type an exact string match against a column they cannot see is the most
 * common way filter UIs fail non-technical users — they type "emea", get zero
 * rows and conclude the tool is broken.
 */
export default function FilterEditor({ meta, filters, onChange, compact }) {
  const [adding, setAdding] = useState(false);
  const props = filterableProps(meta);

  const add = (p) => {
    const cfg = kindConfig(p.type);
    onChange((list) => {
      list.push({
        id: uid("f"),
        property: p.apiName,
        operator: cfg.defaultOperator,
        value: cfg.defaultOperator === "in" ? [] : cfg.defaultOperator === "lastN" ? "90d" : null
      });
    });
    setAdding(false);
  };

  return (
    <div className={compact ? "filters compact" : "filters"}>
      {filters.map((f, i) => (
        <FilterRow
          key={f.id}
          meta={meta}
          filter={f}
          onChange={(fn) => onChange((list) => fn(list[i]))}
          onRemove={() => onChange((list) => list.splice(i, 1))}
        />
      ))}

      <span className="chip-wrap">
        <button className="btn ghost sm" onClick={() => setAdding((v) => !v)}>+ Filter</button>
        <Popover open={adding} onClose={() => setAdding(false)} width={280}>
          <div className="pop-head">Only include rows where…</div>
          <FieldPicker properties={props} onPick={add} />
        </Popover>
      </span>
    </div>
  );
}

function FilterRow({ meta, filter, onChange, onRemove }) {
  const [open, setOpen] = useState(false);
  const prop = propOf(meta, filter.property);
  if (!prop) return null;
  const cfg = kindConfig(prop.type);
  const op = OPERATORS[filter.operator];

  return (
    <span className="chip-wrap">
      <span className="fchip">
        <button className="fchip-body" onClick={() => setOpen(!open)}>
          <b>{prop.displayName}</b>
          <span>{op?.label}</span>
          <em>{summarize(filter, op)}</em>
        </button>
        <button className="fchip-x" onClick={onRemove} aria-label="Remove filter">×</button>
      </span>

      <Popover open={open} onClose={() => setOpen(false)} width={272}>
        <div className="pop-head">{prop.displayName}</div>
        <div className="opt-list">
          {cfg.operators.map((o) => (
            <button
              key={o}
              className={`opt${filter.operator === o ? " on" : ""}`}
              onClick={() => onChange((f) => {
                f.operator = o;
                f.value = OPERATORS[o].input === "multi" ? [] : OPERATORS[o].input === "relative" ? "90d" : null;
              })}
            >
              {OPERATORS[o].label}
            </button>
          ))}
        </div>
        <ValueInput meta={meta} prop={prop} filter={filter} onChange={onChange} />
      </Popover>
    </span>
  );
}

function summarize(f, op) {
  if (!op) return "";
  if (op.input === "none") return "";
  if (op.input === "multi") {
    const v = f.value ?? [];
    if (!v.length) return "anything";
    return v.length <= 2 ? v.join(", ") : `${v.length} selected`;
  }
  if (op.input === "relative") {
    return RELATIVE_PRESETS.find((r) => r.value === f.value)?.label ?? f.value;
  }
  if (op.input === "range") return (f.value ?? []).join(" – ") || "…";
  return f.value ?? "…";
}

/** The input control is chosen by the operator, never hardcoded per field. */
function ValueInput({ meta, prop, filter, onChange }) {
  const provider = useProvider();
  const op = OPERATORS[filter.operator];
  const [values, setValues] = useState(null);
  const [range, setRange] = useState(null);

  useEffect(() => {
    let live = true;
    if (op?.input === "multi" || op?.input === "value") {
      provider.distinctValues(meta.apiName, prop.apiName, 20).then((v) => live && setValues(v));
    }
    if (op?.input === "range") {
      provider.numericRange(meta.apiName, prop.apiName).then((r) => live && setRange(r));
    }
    return () => { live = false; };
  }, [provider, meta.apiName, prop.apiName, op?.input]);

  if (!op || op.input === "none") return null;

  if (op.input === "multi" || op.input === "value") {
    const selected = op.input === "multi" ? filter.value ?? [] : [filter.value];
    return (
      <div className="vlist">
        {!values && <div className="picker-empty">Loading values…</div>}
        {values?.map((v) => (
          <button
            key={v.value}
            className={`vrow${selected.includes(v.value) ? " on" : ""}`}
            onClick={() => onChange((f) => {
              if (op.input === "multi") {
                const cur = f.value ?? [];
                f.value = cur.includes(v.value) ? cur.filter((x) => x !== v.value) : [...cur, v.value];
              } else {
                f.value = v.value;
              }
            })}
          >
            <span className="vbox">{selected.includes(v.value) ? "✓" : ""}</span>
            <span className="vname">{v.value}</span>
            <span className="vcount">{v.count.toLocaleString()}</span>
          </button>
        ))}
      </div>
    );
  }

  if (op.input === "relative") {
    return (
      <div className="unit-row">
        {RELATIVE_PRESETS.map((r) => (
          <button
            key={r.value}
            className={`unit${filter.value === r.value ? " on" : ""}`}
            onClick={() => onChange((f) => { f.value = r.value; })}
          >
            {r.label}
          </button>
        ))}
      </div>
    );
  }

  if (op.input === "range") {
    const v = filter.value ?? [range?.min ?? 0, range?.max ?? 100];
    return (
      <div className="range-row">
        <input type="number" className="ctl sm" value={v[0] ?? ""} placeholder={String(range?.min ?? "")} 
               onChange={(e) => onChange((f) => { f.value = [e.target.value, v[1]]; })} />
        <span className="sw">and</span>
        <input type="number" className="ctl sm" value={v[1] ?? ""} placeholder={String(range?.max ?? "")}
               onChange={(e) => onChange((f) => { f.value = [v[0], e.target.value]; })} />
      </div>
    );
  }

  return (
    <input
      className="ctl sm"
      type={op.input === "date" || op.input === "dateRange" ? "date" : "text"}
      value={filter.value ?? ""}
      onChange={(e) => onChange((f) => { f.value = e.target.value; })}
      placeholder="Value"
    />
  );
}
