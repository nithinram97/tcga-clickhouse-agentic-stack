import { PALETTES, paletteColors } from "../config/palettes.js";

/**
 * Colours and names.
 *
 * Two ideas here that matter more than they look:
 *
 * 1. Renaming a segment is editing a LABEL, never the data. "EMEA" becomes
 *    "Europe & Middle East" for readers; the query still filters on EMEA. Tools
 *    that make you rename upstream force a technical task onto the person least
 *    able to do it.
 * 2. Colour is per-series and remembered by the series' real name, so a series
 *    keeps its colour when filters reorder the chart. Nothing is more confusing
 *    than a chart where the same category changes colour between two views.
 */
export default function StylePanel({ widget, seriesNames, onChange }) {
  const style = widget.style ?? {};
  const palette = paletteColors(style.palette);

  return (
    <div className="style-panel">
      <div className="sect-label">Colour set</div>
      <div className="pal-grid">
        {Object.entries(PALETTES).map(([id, p]) => (
          <button
            key={id}
            className={`pal${style.palette === id ? " on" : ""}`}
            onClick={() => onChange((w) => { w.style.palette = id; w.style.colors = {}; })}
            title={p.note ? `${p.label} — ${p.note}` : p.label}
          >
            <span className="pal-swatches">
              {p.colors.slice(0, 5).map((c) => (
                <i key={c} style={{ background: c }} />
              ))}
            </span>
            <span className="pal-label">
              {p.label}
              {p.note && <em>{p.note}</em>}
            </span>
          </button>
        ))}
      </div>

      {seriesNames.length > 0 && (
        <>
          <div className="sect-label mt">Segments</div>
          <p className="hint-note">Rename or recolour how each one appears. The data is unchanged.</p>
          {seriesNames.map((name, i) => (
            <div className="seg-row" key={name}>
              <label className="seg-color">
                <input
                  type="color"
                  value={style.colors?.[name] ?? palette[i % palette.length]}
                  onChange={(e) => onChange((w) => { w.style.colors = { ...w.style.colors, [name]: e.target.value }; })}
                />
                <span style={{ background: style.colors?.[name] ?? palette[i % palette.length] }} />
              </label>
              <input
                className="ctl sm seg-name"
                value={style.labels?.[name] ?? ""}
                placeholder={name}
                onChange={(e) => onChange((w) => {
                  const labels = { ...w.style.labels };
                  if (e.target.value.trim()) labels[name] = e.target.value;
                  else delete labels[name];
                  w.style.labels = labels;
                })}
              />
              {(style.colors?.[name] || style.labels?.[name]) && (
                <button
                  className="seg-reset"
                  title="Reset to default"
                  onClick={() => onChange((w) => {
                    const c = { ...w.style.colors }; delete c[name];
                    const l = { ...w.style.labels }; delete l[name];
                    w.style.colors = c; w.style.labels = l;
                  })}
                >
                  ↺
                </button>
              )}
            </div>
          ))}
        </>
      )}

      <div className="sect-label mt">Numbers</div>
      <div className="seg">
        {[
          { v: "auto", label: "Auto" },
          { v: "compact", label: "1.2k" },
          { v: "full", label: "1,200" }
        ].map((o) => (
          <button
            key={o.v}
            className={(style.format ?? "auto") === o.v ? "on" : ""}
            onClick={() => onChange((w) => { w.style.format = o.v; })}
          >
            {o.label}
          </button>
        ))}
      </div>

      <label className="checkline">
        <input
          type="checkbox"
          checked={!!style.showValues}
          onChange={(e) => onChange((w) => { w.style.showValues = e.target.checked; })}
        />
        Show values on the chart
      </label>
    </div>
  );
}
