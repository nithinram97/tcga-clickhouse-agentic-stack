import { useState } from "react";
import { kindConfig, isChartable } from "../config/propertyTypes.js";
import Popover from "./Popover.jsx";

/**
 * The data rail.
 *
 * Shows what is available, not what to do. Fields carry their type badge and
 * the ontology's description, so the vocabulary of the data is learnable by
 * browsing — which is how most people build a mental model before they build a
 * chart.
 */
export default function DataRail({ spec, objectTypes, metaFor, onAdd, onRemove, onAddChart }) {
  const [adding, setAdding] = useState(false);
  const [open, setOpen] = useState(() => new Set(spec.objectTypes));
  const available = objectTypes.filter((o) => !spec.objectTypes.includes(o.apiName));

  const toggle = (t) =>
    setOpen((p) => {
      const n = new Set(p);
      n.has(t) ? n.delete(t) : n.add(t);
      return n;
    });

  return (
    <aside className="rail">
      <div className="rail-head">
        <span>Your data</span>
        <span className="chip-wrap">
          <button className="btn icon" onClick={() => setAdding((v) => !v)} disabled={!available.length}>+</button>
          <Popover open={adding} onClose={() => setAdding(false)} width={244}>
            <div className="pop-head">Add another object type</div>
            <div className="picker-list">
              {available.map((o) => (
                <button key={o.apiName} className="picker-row" onClick={() => { onAdd(o.apiName); setAdding(false); }}>
                  <span className="picker-main">
                    <span className="picker-name">{o.displayName}</span>
                    {o.description && <span className="picker-desc">{o.description}</span>}
                  </span>
                </button>
              ))}
            </div>
          </Popover>
        </span>
      </div>

      {spec.objectTypes.map((t) => {
        const meta = metaFor(t);
        if (!meta) return null;
        const used = spec.widgets.filter((w) => w.objectType === t).length;
        const isOpen = open.has(t);
        return (
          <div className={`src${isOpen ? " on" : ""}`} key={t}>
            <div className="src-row" onClick={() => toggle(t)}>
              <span className="src-caret">{isOpen ? "▾" : "▸"}</span>
              <span className="src-name">{meta.displayName}</span>
              <span className="src-count">{used}</span>
            </div>
            {isOpen && (
              <div className="props">
                {meta.properties.filter(isChartable).map((p) => (
                  <div className="prop" key={p.apiName} title={p.description || p.displayName}>
                    <span className="tbadge">{kindConfig(p.type).icon}</span>
                    <span className="prop-name">{p.displayName}</span>
                  </div>
                ))}
                <div className="src-actions">
                  <button className="linkbtn" onClick={() => onAddChart(t)}>+ New chart</button>
                  <button className="linkbtn danger" onClick={() => onRemove(t)}>Remove</button>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </aside>
  );
}
