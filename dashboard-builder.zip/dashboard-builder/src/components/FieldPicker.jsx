import { useMemo, useState } from "react";
import { kindConfig } from "../config/propertyTypes.js";

/**
 * Searchable field list.
 *
 * Type search rather than a raw dropdown, because ontologies routinely have
 * dozens of properties and scanning a flat <select> is the slowest thing a user
 * can be asked to do. Each row carries a type badge and the ontology's own
 * description, so the meaning of a field is visible at the point of choosing it
 * — recognition rather than recall.
 */
export default function FieldPicker({ properties, value, onPick, onClear, clearLabel, footer }) {
  const [q, setQ] = useState("");

  const groups = useMemo(() => {
    const term = q.trim().toLowerCase();
    const match = properties.filter(
      (p) =>
        !term ||
        p.displayName.toLowerCase().includes(term) ||
        p.apiName.toLowerCase().includes(term) ||
        (p.description ?? "").toLowerCase().includes(term)
    );
    const out = new Map();
    match.forEach((p) => {
      const k = kindConfig(p.type).label;
      if (!out.has(k)) out.set(k, []);
      out.get(k).push(p);
    });
    return [...out.entries()];
  }, [properties, q]);

  return (
    <div className="picker">
      <input
        className="picker-search"
        autoFocus
        placeholder="Search fields…"
        value={q}
        onChange={(e) => setQ(e.target.value)}
      />
      <div className="picker-list">
        {onClear && (
          <button className="picker-row muted" onClick={onClear}>
            <span className="tbadge">—</span>
            <span className="picker-name">{clearLabel}</span>
          </button>
        )}
        {groups.map(([kind, props]) => (
          <div key={kind}>
            <div className="picker-group">{kind}</div>
            {props.map((p) => (
              <button
                key={p.apiName}
                className={`picker-row${p.apiName === value ? " on" : ""}`}
                onClick={() => onPick(p)}
              >
                <span className="tbadge">{kindConfig(p.type).icon}</span>
                <span className="picker-main">
                  <span className="picker-name">{p.displayName}</span>
                  {p.description && <span className="picker-desc">{p.description}</span>}
                </span>
              </button>
            ))}
          </div>
        ))}
        {!groups.length && <div className="picker-empty">No field matches “{q}”</div>}
      </div>
      {footer}
    </div>
  );
}
