import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

/**
 * Popover.
 *
 * Rendered into document.body rather than inline, because both the rail and the
 * inspector are scroll containers (`overflow-y: auto`) and would otherwise clip
 * the panel to their own width. Position is computed from the anchor and
 * re-measured on scroll and resize.
 *
 * It also flips above the anchor when there is not enough room below, and caps
 * its height to the viewport so long field lists scroll instead of running off
 * the bottom of the screen.
 */
export default function Popover({ open, onClose, children, align = "left", width = 264 }) {
  const marker = useRef(null);
  const panel = useRef(null);
  const [pos, setPos] = useState(null);

  const place = useCallback(() => {
    const anchor = marker.current?.parentElement;
    if (!anchor) return;
    const r = anchor.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const w = Math.min(width, vw - 16);

    let left = align === "right" ? r.right - w : r.left;
    left = Math.max(8, Math.min(left, vw - w - 8));

    const h = panel.current?.offsetHeight ?? 300;
    const spaceBelow = vh - r.bottom;
    const above = spaceBelow < Math.min(h, 240) + 12 && r.top > spaceBelow;
    const top = above ? Math.max(8, r.top - h - 6) : r.bottom + 6;

    setPos({
      left,
      top,
      width: w,
      maxHeight: above ? r.top - 16 : Math.max(180, vh - top - 12)
    });
  }, [align, width]);

  useLayoutEffect(() => {
    if (!open) { setPos(null); return; }
    place();
    // Re-measure after the panel has content, so flip-up uses a real height.
    const raf = requestAnimationFrame(place);
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
    };
  }, [open, place]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e) => {
      const anchor = marker.current?.parentElement;
      // Clicks on the trigger are its own business — let it toggle.
      if (anchor?.contains(e.target)) return;
      if (panel.current?.contains(e.target)) return;
      onClose();
    };
    const onKey = (e) => { if (e.key === "Escape") { e.stopPropagation(); onClose(); } };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  return (
    <>
      <span ref={marker} className="pop-anchor" aria-hidden="true" />
      {open &&
        createPortal(
          <div
            className="pop"
            ref={panel}
            role="dialog"
            style={pos ? { ...pos, visibility: "visible" } : { visibility: "hidden" }}
          >
            {children}
          </div>,
          document.body
        )}
    </>
  );
}
