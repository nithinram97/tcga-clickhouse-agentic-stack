/**
 * localStorage-backed store.
 *
 * Implements exactly the same interface as dashboardStore.js, so useDashboard
 * and App never learn which one they have. That is what lets the mock and the
 * real Foundry build share a single code path — the alternative is two
 * persistence branches that drift apart.
 */
const KEY = "dashboard:v3";
const VERSION_LIMIT = 10;

const read = () => {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "null");
  } catch {
    return null;
  }
};

const write = (rec) => {
  try {
    localStorage.setItem(KEY, JSON.stringify(rec));
  } catch {}
  return rec;
};

export function createLocalStore({ currentUser = "you" } = {}) {
  return {
    id: "local",

    async listMine() {
      const r = read();
      return r ? [r] : [];
    },

    async listAll() {
      return this.listMine();
    },

    async load() {
      return read();
    },

    async create(name, spec) {
      return write({
        primaryKey: "local",
        name,
        user: currentUser,
        envelope: 1,
        draft: spec,
        published: null,
        publishedVersion: 0,
        versions: []
      });
    },

    async saveDraft(record, spec) {
      return write({ ...record, draft: spec });
    },

    async publish(record, spec, label) {
      const version = (record.publishedVersion ?? 0) + 1;
      const entry = { version, at: new Date().toISOString(), by: currentUser, label, spec };
      write({
        ...record,
        draft: spec,
        published: spec,
        publishedVersion: version,
        versions: [entry, ...(record.versions ?? [])].slice(0, VERSION_LIMIT)
      });
      return entry;
    },

    async restore(record, version) {
      const found = (record.versions ?? []).find((v) => v.version === version);
      if (!found) return null;
      write({ ...record, draft: found.spec });
      return found.spec;
    },

    async rename(record, name) {
      return write({ ...record, name });
    },

    async remove() {
      try {
        localStorage.removeItem(KEY);
      } catch {}
    },

    subscribe() {
      return { unsubscribe() {} };
    }
  };
}
