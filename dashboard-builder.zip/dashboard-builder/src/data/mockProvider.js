import { kindOf } from "../config/propertyTypes.js";

/**
 * Generic mock provider.
 *
 * Works against ANY schema handed to it — it has no knowledge of specific object
 * types or property names. Values are derived from a hash of the query, so they
 * are stable across renders and change visibly when the query changes.
 *
 * Where a schema property supplies `sampleValues`, those are used so the demo
 * reads naturally. Where it does not, synthetic values are generated. That is
 * the only concession to demo-friendliness, and it lives in data, not code.
 */
function hash(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

function timeBuckets(unit, count) {
  const n = Math.min(count, unit === "years" ? 5 : unit === "quarters" ? 8 : 12);
  const now = new Date();
  const out = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now);
    if (unit === "years") { d.setFullYear(d.getFullYear() - i); out.push(String(d.getFullYear())); }
    else if (unit === "quarters") { d.setMonth(d.getMonth() - i * 3); out.push(`Q${Math.floor(d.getMonth() / 3) + 1} ${String(d.getFullYear()).slice(2)}`); }
    else if (unit === "weeks") { d.setDate(d.getDate() - i * 7); out.push(`${d.getDate()} ${MONTHS[d.getMonth()]}`); }
    else if (unit === "days") { d.setDate(d.getDate() - i); out.push(`${d.getDate()} ${MONTHS[d.getMonth()]}`); }
    else { d.setMonth(d.getMonth() - i); out.push(`${MONTHS[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`); }
  }
  return out;
}

export function createMockProvider(schema) {
  const byName = Object.fromEntries(schema.objectTypes.map((o) => [o.apiName, o]));
  const propOf = (ot, api) => byName[ot]?.properties.find((p) => p.apiName === api);

  const valuesFor = (ot, api, limit = 8) => {
    const p = propOf(ot, api);
    if (!p) return [];
    const kind = kindOf(p.type);
    if (p.sampleValues?.length) return p.sampleValues.slice(0, limit);
    if (kind === "boolean") return ["Yes", "No"];
    if (kind === "number") {
      const step = 100;
      return Array.from({ length: Math.min(limit, 5) }, (_, i) => `${i * step}–${(i + 1) * step}`);
    }
    // No sample values configured: synthesise stable, obviously-fake labels.
    const n = Math.min(limit, 4 + (hash(ot + api) % 4));
    return Array.from({ length: n }, (_, i) => `${p.displayName} ${i + 1}`);
  };

  return {
    id: "mock",

    async listObjectTypes() {
      return schema.objectTypes.map(({ apiName, displayName, description }) => ({
        apiName, displayName, description
      }));
    },

    async describeObjectType(apiName) {
      const o = byName[apiName];
      if (!o) throw new Error(`Unknown object type: ${apiName}`);
      return {
        apiName: o.apiName,
        displayName: o.displayName,
        description: o.description,
        primaryKey: o.primaryKey,
        properties: o.properties.map((p) => ({
          apiName: p.apiName,
          displayName: p.displayName,
          description: p.description,
          type: p.type
        })),
        links: o.links ?? []
      };
    },

    async distinctValues(objectType, property, limit = 12) {
      return valuesFor(objectType, property, limit).map((value) => ({
        value,
        count: 200 + (hash(objectType + property + value) % 4000)
      }));
    },

    async numericRange(objectType, property) {
      const h = hash(objectType + property);
      const min = 0;
      const max = 100 * (2 + (h % 40));
      return { min, max };
    },

    async aggregate(query) {
      const { objectType, groupBy, split, measures, limit = 12, where } = query;
      const salt = JSON.stringify(where ?? {});

      let keys = ["All"];
      if (groupBy) {
        const p = propOf(objectType, groupBy.property);
        keys =
          kindOf(p?.type) === "time"
            ? timeBuckets(groupBy.options?.unit ?? "months", limit)
            : valuesFor(objectType, groupBy.property, limit);
      }

      const splitKeys = split ? valuesFor(objectType, split.property, split.limit ?? 4) : [null];

      const series = [];
      const emit = (name, measure, splitKey) => {
        const values = keys.map((k, i) => {
          const seed = [objectType, measure.property, measure.fn, k, splitKey, salt].join("|");
          const n = hash(seed);
          const base =
            measure.fn === "count" ? 400 + (n % 3000)
            : measure.fn === "avg" ? 40 + (n % 400)
            : measure.fn === "approximateDistinct" ? 5 + (n % 60)
            : 1000 + (n % 9000);
          const decay = groupBy ? 1 - i * 0.06 : 1;
          const splitShare = splitKey ? 0.45 : 1;
          return Math.max(1, Math.round(base * decay * splitShare));
        });
        series.push({ name, values, measureId: measure.id, splitKey });
      };

      if (split) {
        const m = measures[0];
        splitKeys.forEach((sk) => emit(String(sk), m, sk));
      } else {
        measures.forEach((m) => emit(m.label, m, null));
      }

      return { keys, series, truncated: groupBy ? keys.length >= limit : false };
    }
  };
}
