import { createContext, useContext } from "react";

/**
 * DataProvider contract.
 *
 * Every screen in this app talks to the ontology only through these five
 * methods. Swapping the mock for real OSDK is one line in main.jsx; no
 * component knows which is in use.
 *
 *   listObjectTypes()                      → [{ apiName, displayName, description }]
 *   describeObjectType(apiName)            → { apiName, displayName, properties[], links[] }
 *   distinctValues(apiName, property, n)   → [{ value, count }]
 *   numericRange(apiName, property)        → { min, max }
 *   aggregate(query)                       → { keys[], series[] }
 *
 * `query` is the neutral shape produced by lib/compile.js:
 *   { objectType, where, groupBy, split, measures[], limit }
 */
export const DataProviderContext = createContext(null);

export const useProvider = () => {
  const p = useContext(DataProviderContext);
  if (!p) throw new Error("No DataProvider in context");
  return p;
};
