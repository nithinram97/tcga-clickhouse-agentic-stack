/**
 * Stand-in for the Foundry packages when they are not installed.
 *
 * Aliased in by vite.config.js. Nothing reaches these unless the app is started
 * with VITE_DATA_SOURCE=foundry without the SDK present, in which case the error
 * says exactly what to install.
 */
const INSTALL =
  'npm i @fdc9-skywiseperfodynamiclp/sdk @osdk/client @osdk/oauth @osdk/foundry';

const fail = () => {
  throw new Error(
    `The Foundry SDK is not installed, but VITE_DATA_SOURCE=foundry. Run:\n  ${INSTALL}\n` +
      `Or unset VITE_DATA_SOURCE to use the built-in mock ontology.`
  );
};

export const createClient = fail;
export const createPublicOauthClient = fail;
export const Users = { getCurrent: fail };
export default {};
