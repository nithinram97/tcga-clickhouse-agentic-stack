import { useEffect, useRef, useState } from "react";
import { useProvider } from "../data/provider.js";
import { compileQuery } from "../lib/compile.js";

const cache = new Map();

/**
 * Runs one widget's query.
 *
 * Keyed on the compiled query, so two widgets asking the same question share a
 * result and re-rendering for unrelated reasons costs nothing. Keeps the last
 * successful data during a refetch so charts fade rather than flash empty —
 * visibility of system status without a spinner storm.
 */
export function useWidgetData(meta, widget, extraFilters) {
  const provider = useProvider();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const last = useRef(null);

  const query = meta ? compileQuery(meta, widget, extraFilters) : null;
  const key = query ? JSON.stringify(query) : null;

  useEffect(() => {
    if (!key || !query) return;
    let live = true;

    if (cache.has(key)) {
      setData(cache.get(key));
      setLoading(false);
      setError(null);
      last.current = cache.get(key);
      return;
    }

    setLoading(true);
    provider
      .aggregate(query)
      .then((res) => {
        if (!live) return;
        cache.set(key, res);
        if (cache.size > 200) cache.delete(cache.keys().next().value);
        last.current = res;
        setData(res);
        setError(null);
      })
      .catch((e) => live && setError(e))
      .finally(() => live && setLoading(false));

    return () => { live = false; };
  }, [key, provider]);

  return { data: data ?? last.current, loading, error, query };
}
