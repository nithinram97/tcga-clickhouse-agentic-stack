import { useCallback, useEffect, useState } from "react";
import { useProvider } from "../data/provider.js";

/**
 * Loads and caches ontology metadata.
 *
 * Everything the UI knows about an object type comes from here, which is why
 * pointing the app at a different ontology needs no code change.
 */
export function useOntology() {
  const provider = useProvider();
  const [objectTypes, setObjectTypes] = useState([]);
  const [meta, setMeta] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let live = true;
    (async () => {
      const list = await provider.listObjectTypes();
      if (!live) return;
      setObjectTypes(list);
      const described = await Promise.all(
        list.map((o) => provider.describeObjectType(o.apiName))
      );
      if (!live) return;
      setMeta(Object.fromEntries(described.map((m) => [m.apiName, m])));
      setLoading(false);
    })();
    return () => { live = false; };
  }, [provider]);

  const metaFor = useCallback((apiName) => meta[apiName] ?? null, [meta]);
  return { objectTypes, meta, metaFor, loading };
}
