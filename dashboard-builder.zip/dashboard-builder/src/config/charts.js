import { AGGREGATIONS } from "./propertyTypes.js";

/**
 * Chart registry. Availability is declarative: `fits(shape)` receives a
 * description of the query and returns true, or a string explaining why not.
 *
 * The string matters. A disabled control that says nothing teaches the user
 * nothing; one that says "pie charts get unreadable past 7 slices" teaches them
 * something about their data. (Nielsen: help users recognise and recover, and
 * prefer prevention over error messages.)
 */
export const CHARTS = {
  bar: {
    label: "Bars", icon: "▤",
    hint: "Compare values across categories",
    fits: (s) => (s.hasGroup ? true : "Pick something to break down by first")
  },
  column: {
    label: "Horizontal bars", icon: "▥",
    hint: "Good when category names are long",
    fits: (s) => (s.hasGroup ? true : "Pick something to break down by first")
  },
  line: {
    label: "Line", icon: "◺",
    hint: "Show a trend",
    fits: (s) =>
      !s.hasGroup ? "Pick something to break down by first"
      : s.groupIsTime ? true
      : "Lines imply an order — best with a date"
  },
  area: {
    label: "Area", icon: "◣",
    hint: "Trend with volume",
    fits: (s) =>
      !s.hasGroup ? "Pick something to break down by first"
      : s.groupIsTime ? true
      : "Best with a date"
  },
  donut: {
    label: "Donut", icon: "◐",
    hint: "Share of a whole",
    fits: (s) =>
      !s.hasGroup ? "Pick something to break down by first"
      : s.measureCount > 1 ? "Only one measure fits in a donut"
      : s.hasSplit ? "A donut can only show one breakdown"
      : s.groupCount > 7 ? `${s.groupCount} slices is too many to read — try bars`
      : true
  },
  table: { label: "Table", icon: "☰", hint: "Exact numbers", fits: () => true },
  kpi: {
    label: "Single number", icon: "#",
    hint: "One headline figure",
    fits: (s) => (s.hasGroup ? "Remove the breakdown to show one number" : true)
  }
};

export const CHART_ORDER = ["bar", "column", "line", "area", "donut", "table", "kpi"];

/** Charts that draw via Vega-Lite (the rest are plain markup). */
export const VEGA_CHARTS = new Set(["bar", "column", "line", "area", "donut"]);

export const aggLabel = (fn) => AGGREGATIONS[fn]?.label ?? fn;
