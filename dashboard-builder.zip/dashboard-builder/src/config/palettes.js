/**
 * Palettes.
 *
 * The default is colorblind-safe (Okabe–Ito, designed for the ~8% of men with
 * some form of colour vision deficiency). Making the safe option the default,
 * rather than an accessibility toggle somewhere, means the majority of charts
 * built here are readable without anyone having to know why.
 */
export const PALETTES = {
  accessible: {
    label: "Accessible",
    note: "Colourblind-safe",
    colors: ["#0072B2", "#E69F00", "#009E73", "#CC79A7", "#56B4E9", "#D55E00", "#F0E442", "#8C8C8C"]
  },
  calm: {
    label: "Calm",
    colors: ["#1d7a68", "#7a6fd0", "#5aa896", "#c98b3f", "#9ecabe", "#9aa4b4", "#4a7fa8", "#b0708a"]
  },
  bold: {
    label: "Bold",
    colors: ["#2f3fd4", "#e0403f", "#0f9d58", "#f4b400", "#7c3aed", "#0891b2", "#db2777", "#65a30d"]
  },
  sequential: {
    label: "One colour",
    note: "For ordered values",
    colors: ["#0b3d54", "#155e75", "#1d7f9c", "#38a3bd", "#67c3d6", "#9adbe6", "#c5ecf2", "#e4f6f9"]
  },
  grey: {
    label: "Neutral",
    colors: ["#3f4854", "#5b6675", "#78838f", "#95a0ac", "#b2bcc6", "#cfd6dd", "#e2e7ec", "#f1f4f7"]
  }
};

export const DEFAULT_PALETTE = "accessible";
export const paletteColors = (id) => (PALETTES[id] || PALETTES[DEFAULT_PALETTE]).colors;
