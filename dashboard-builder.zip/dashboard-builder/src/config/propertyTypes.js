/**
 * THE CORE CONFIG.
 *
 * Everything the builder can do is derived from a property's TYPE, never its
 * name. No file in this project branches on a property called "revenue" or an
 * object type called "Order" — if one did, the app would stop being
 * ontology-agnostic.
 *
 * To support a new Foundry property type, add an entry here. Nothing else needs
 * to change: pickers, filters, chart availability and the OSDK compiler all read
 * from this table.
 */

/** Foundry / OSDK property types → the kinds this app reasons about. */
export const TYPE_ALIASES = {
  string: "text",
  boolean: "boolean",
  byte: "number",
  short: "number",
  integer: "number",
  long: "number",
  float: "number",
  double: "number",
  decimal: "number",
  date: "time",
  timestamp: "time",
  geopoint: "geo",
  geoshape: "geo",
  geohash: "geo",
  attachment: "unsupported",
  mediaReference: "unsupported",
  marking: "unsupported",
  array: "unsupported",
  struct: "unsupported",
  vector: "unsupported"
};

export const kindOf = (osdkType) => TYPE_ALIASES[osdkType] || "unsupported";

/**
 * Aggregations, phrased the way a non-technical reader would say them.
 * `osdk` is the suffix used in the OSDK $select key ("revenue:sum").
 */
export const AGGREGATIONS = {
  count: { osdk: null, label: "How many", short: "count", needsProperty: false },
  sum: { osdk: "sum", label: "Total", short: "total" },
  avg: { osdk: "avg", label: "Average", short: "average" },
  max: { osdk: "max", label: "Highest", short: "highest" },
  min: { osdk: "min", label: "Lowest", short: "lowest" },
  approximateDistinct: { osdk: "approximateDistinct", label: "Distinct values", short: "distinct" }
};

/**
 * Grouping strategies. `build()` returns the OSDK $groupBy value, so the query
 * compiler never needs to know which strategy it is handling.
 */
export const GROUPINGS = {
  exact: { label: "each value", build: () => "exact" },
  topValues: { label: "top values only", build: () => "topValues" },
  fixedWidth: {
    label: "number ranges",
    defaults: { width: 100 },
    build: (o = {}) => ({ $fixedWidth: o.width ?? 100 })
  },
  duration: {
    label: "over time",
    defaults: { unit: "months", count: 1 },
    units: ["days", "weeks", "months", "quarters", "years"],
    build: (o = {}) => ({ $duration: [o.count ?? 1, o.unit ?? "months"] })
  }
};

/**
 * Filter operators. `build(apiName, value)` returns an OSDK `where` fragment,
 * so adding an operator never touches the query compiler.
 */
export const OPERATORS = {
  in:        { label: "is any of",    input: "multi",     build: (p, v) => ({ $or: (v || []).map((x) => ({ [p]: { $eq: x } })) }) },
  notIn:     { label: "is none of",   input: "multi",     build: (p, v) => ({ $not: { $or: (v || []).map((x) => ({ [p]: { $eq: x } })) } }) },
  eq:        { label: "is",           input: "value",     build: (p, v) => ({ [p]: { $eq: v } }) },
  ne:        { label: "is not",       input: "value",     build: (p, v) => ({ $not: { [p]: { $eq: v } } }) },
  contains:  { label: "contains",     input: "text",      build: (p, v) => ({ [p]: { $contains: v } }) },
  gt:        { label: "is more than", input: "number",    build: (p, v) => ({ [p]: { $gt: Number(v) } }) },
  lt:        { label: "is less than", input: "number",    build: (p, v) => ({ [p]: { $lt: Number(v) } }) },
  between:   { label: "is between",   input: "range",     build: (p, v) => ({ $and: [{ [p]: { $gte: Number(v?.[0]) } }, { [p]: { $lte: Number(v?.[1]) } }] }) },
  after:     { label: "is after",     input: "date",      build: (p, v) => ({ [p]: { $gt: v } }) },
  before:    { label: "is before",    input: "date",      build: (p, v) => ({ [p]: { $lt: v } }) },
  dateRange: { label: "is between",   input: "dateRange", build: (p, v) => ({ $and: [{ [p]: { $gte: v?.[0] } }, { [p]: { $lte: v?.[1] } }] }) },
  lastN:     { label: "in the last",  input: "relative",  build: (p, v) => ({ [p]: { $gte: relativeIso(v) } }) },
  isTrue:    { label: "is yes",       input: "none",      build: (p) => ({ [p]: { $eq: true } }) },
  isFalse:   { label: "is no",        input: "none",      build: (p) => ({ [p]: { $eq: false } }) },
  isNull:    { label: "is empty",     input: "none",      build: (p) => ({ [p]: { $isNull: true } }) },
  notNull:   { label: "is not empty", input: "none",      build: (p) => ({ $not: { [p]: { $isNull: true } } }) }
};

export const RELATIVE_PRESETS = [
  { value: "7d", label: "7 days" },
  { value: "30d", label: "30 days" },
  { value: "90d", label: "90 days" },
  { value: "12m", label: "12 months" }
];

function relativeIso(v) {
  const n = parseInt(v, 10) || 30;
  const unit = String(v || "").slice(-1);
  const d = new Date();
  if (unit === "m") d.setMonth(d.getMonth() - n);
  else d.setDate(d.getDate() - n);
  return d.toISOString();
}

/** What each kind of property can do. This is the whole capability model. */
export const KINDS = {
  text: {
    label: "Text", icon: "Ab",
    canGroup: true, canMeasure: false,
    groupings: ["exact", "topValues"],
    aggregations: ["count", "approximateDistinct"],
    operators: ["in", "notIn", "eq", "ne", "contains", "isNull", "notNull"],
    defaultOperator: "in", defaultGrouping: "exact"
  },
  number: {
    label: "Number", icon: "#",
    canGroup: true, canMeasure: true,
    groupings: ["fixedWidth", "exact"],
    aggregations: ["sum", "avg", "max", "min", "count", "approximateDistinct"],
    operators: ["between", "gt", "lt", "eq", "isNull", "notNull"],
    defaultOperator: "between", defaultGrouping: "fixedWidth", defaultAggregation: "sum"
  },
  time: {
    label: "Date", icon: "◷",
    canGroup: true, canMeasure: false, isTime: true,
    groupings: ["duration"],
    aggregations: ["count", "max", "min"],
    operators: ["lastN", "dateRange", "after", "before", "isNull", "notNull"],
    defaultOperator: "lastN", defaultGrouping: "duration"
  },
  boolean: {
    label: "Yes / no", icon: "◑",
    canGroup: true, canMeasure: false,
    groupings: ["exact"],
    aggregations: ["count"],
    operators: ["isTrue", "isFalse", "isNull", "notNull"],
    defaultOperator: "isTrue", defaultGrouping: "exact"
  },
  geo: {
    label: "Location", icon: "◎",
    canGroup: false, canMeasure: false,
    groupings: [], aggregations: ["count"],
    operators: ["isNull", "notNull"], defaultOperator: "notNull"
  },
  unsupported: {
    label: "Not chartable", icon: "·", hidden: true,
    canGroup: false, canMeasure: false,
    groupings: [], aggregations: [], operators: []
  }
};

export const kindConfig = (osdkType) => KINDS[kindOf(osdkType)];
export const canGroup = (p) => kindConfig(p.type).canGroup;
export const canMeasure = (p) => kindConfig(p.type).canMeasure;
export const isTime = (p) => !!kindConfig(p.type).isTime;
export const isChartable = (p) => !kindConfig(p.type).hidden;
