import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import { DataProviderContext } from "./data/provider.js";
import { bootstrap } from "./data/bootstrap.js";
import "./styles.css";

const root = createRoot(document.getElementById("root"));
root.render(<div className="boot">Starting…</div>);

bootstrap()
  .then(({ provider, store, mode }) => {
    root.render(
      <React.StrictMode>
        <DataProviderContext.Provider value={provider}>
          <App store={store} mode={mode} />
        </DataProviderContext.Provider>
      </React.StrictMode>
    );
  })
  .catch((e) => {
    console.error(e);
    root.render(
      <div className="boot error">
        <strong>Could not start</strong>
        <span>{String(e?.message ?? e)}</span>
      </div>
    );
  });
